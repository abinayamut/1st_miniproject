package com.example.library_management.dto;

import jakarta.validation.constraints.NotNull;

/**
 * DTO for book borrowing requests
 */
public class BorrowBookDto {
    
    @NotNull(message = "Book ID is required")
    private Long bookId;
    
    @NotNull(message = "User ID is required")
    private Long userId;
    
    private Integer borrowDays;
    
    // Default constructor
    public BorrowBookDto() {}
    
    // Constructor
    public BorrowBookDto(Long bookId, Long userId, Integer borrowDays) {
        this.bookId = bookId;
        this.userId = userId;
        this.borrowDays = borrowDays;
    }
    
    // Getters and setters
    public Long getBookId() {
        return bookId;
    }
    
    public void setBookId(Long bookId) {
        this.bookId = bookId;
    }
    
    public Long getUserId() {
        return userId;
    }
    
    public void setUserId(Long userId) {
        this.userId = userId;
    }
    
    public Integer getBorrowDays() {
        return borrowDays;
    }
    
    public void setBorrowDays(Integer borrowDays) {
        this.borrowDays = borrowDays;
    }
}