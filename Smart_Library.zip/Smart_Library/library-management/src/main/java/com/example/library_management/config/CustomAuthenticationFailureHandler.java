package com.example.library_management.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.authentication.BadCredentialsException;
import org.springframework.security.authentication.DisabledException;
import org.springframework.security.authentication.LockedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.security.web.authentication.AuthenticationFailureHandler;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;

/**
 * Custom Authentication Failure Handler for detailed error messages
 */
@Component
public class CustomAuthenticationFailureHandler implements AuthenticationFailureHandler {

    private static final Logger logger = LoggerFactory.getLogger(CustomAuthenticationFailureHandler.class);
    
    private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    @Override
    public void onAuthenticationFailure(HttpServletRequest request, 
                                      HttpServletResponse response,
                                      AuthenticationException exception) throws IOException {

        String username = request.getParameter("username");
        String errorMessage = getErrorMessage(exception);
        
        // Log the failed authentication attempt
        logger.warn("Authentication failed for user '{}': {}", username, exception.getMessage());

        String targetUrl = "/login?error=true&message=" + 
            URLEncoder.encode(errorMessage, StandardCharsets.UTF_8);

        redirectStrategy.sendRedirect(request, response, targetUrl);
    }

    /**
     * Get user-friendly error message based on exception type
     */
    private String getErrorMessage(AuthenticationException exception) {
        if (exception instanceof BadCredentialsException) {
            return "Invalid username or password. Please try again.";
        } else if (exception instanceof LockedException) {
            return "Your account has been locked. Please contact administrator.";
        } else if (exception instanceof DisabledException) {
            return "Your account has been disabled. Please contact administrator.";
        } else {
            return "Authentication failed. Please try again.";
        }
    }
}