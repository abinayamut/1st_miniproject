package com.example.library_management.exception;

/**
 * Exception thrown when a requested resource is not found
 */
public class ResourceNotFoundException extends LibraryManagementException {
    
    public ResourceNotFoundException(String resourceName, Object resourceId) {
        super(String.format("%s not found with id: %s", resourceName, resourceId));
    }
    
    public ResourceNotFoundException(String message) {
        super(message);
    }
}