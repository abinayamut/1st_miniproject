package com.example.library_management.config;

import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.web.authentication.AuthenticationSuccessHandler;
import org.springframework.security.web.DefaultRedirectStrategy;
import org.springframework.security.web.RedirectStrategy;
import org.springframework.stereotype.Component;

import java.io.IOException;
import java.util.Collection;

/**
 * Custom Authentication Success Handler for role-based redirection
 * Redirects users to their respective dashboards based on their roles
 */
@Component
public class CustomAuthenticationSuccessHandler implements AuthenticationSuccessHandler {

    private static final Logger logger = LoggerFactory.getLogger(CustomAuthenticationSuccessHandler.class);
    
    private RedirectStrategy redirectStrategy = new DefaultRedirectStrategy();

    @Override
    public void onAuthenticationSuccess(HttpServletRequest request, 
                                      HttpServletResponse response,
                                      Authentication authentication) throws IOException {

        String targetUrl = determineTargetUrl(authentication);
        
        if (response.isCommitted()) {
            logger.debug("Response has already been committed. Unable to redirect to " + targetUrl);
            return;
        }

        // Log successful authentication
        String username = authentication.getName();
        logger.info("User '{}' successfully authenticated and redirected to '{}'", username, targetUrl);

        redirectStrategy.sendRedirect(request, response, targetUrl);
    }

    /**
     * Determines the target URL based on user role
     */
    protected String determineTargetUrl(Authentication authentication) {
        Collection<? extends GrantedAuthority> authorities = authentication.getAuthorities();
        
        // Get user details for additional information if needed
        String username = authentication.getName();
        
        for (GrantedAuthority authority : authorities) {
            String role = authority.getAuthority();
            
            switch (role) {
                case "ROLE_ADMIN":
                    logger.debug("Redirecting admin user '{}' to admin dashboard", username);
                    return "/admin/dashboard";
                    
                case "ROLE_LIBRARIAN":
                    logger.debug("Redirecting librarian user '{}' to librarian dashboard", username);
                    return "/librarian/dashboard";
                    
                case "ROLE_STUDENT":
                    logger.debug("Redirecting student user '{}' to student dashboard", username);
                    return "/student/dashboard";
                    
                default:
                    logger.warn("Unknown role '{}' for user '{}', redirecting to home page", role, username);
                    break;
            }
        }
        
        // Default fallback - should not happen in normal circumstances
        logger.warn("No valid role found for user '{}', redirecting to home page", username);
        return "/";
    }
}