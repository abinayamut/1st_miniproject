package com.example.library_management.controller.api;

import com.example.library_management.dto.ApiResponse;
import com.example.library_management.dto.CreateUserDto;
import com.example.library_management.entity.Role;
import com.example.library_management.entity.User;
import com.example.library_management.service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

/**
 * REST API controller for user management
 */
@RestController
@RequestMapping("/api/v1/users")
@Validated
public class UserApiController {

    @Autowired
    private UserService userService;

    /**
     * Get all users (Admin only)
     */
    @GetMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<User>>> getAllUsers() {
        List<User> users = userService.getAllUsers();
        return ResponseEntity.ok(ApiResponse.success(users, "Users retrieved successfully"));
    }

    /**
     * Get user by ID (Admin only)
     */
    @GetMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<User>> getUserById(@PathVariable Long id) {
        Optional<User> user = userService.findById(id);
        
        if (user.isPresent()) {
            return ResponseEntity.ok(ApiResponse.success(user.get(), "User found"));
        } else {
            return ResponseEntity.notFound().build();
        }
    }

    /**
     * Create a new user (Admin only)
     */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<User>> createUser(@Valid @RequestBody CreateUserDto userDto) {
        User user = convertToEntity(userDto);
        User createdUser = userService.createUser(user);
        
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success(createdUser, "User created successfully"));
    }

    /**
     * Update user status (Admin only)
     */
    @PutMapping("/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<User>> toggleUserStatus(@PathVariable Long id) {
        User updatedUser = userService.toggleUserStatus(id);
        return ResponseEntity.ok(ApiResponse.success(updatedUser, "User status updated"));
    }

    /**
     * Get users by role (Admin only)
     */
    @GetMapping("/role/{role}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<List<User>>> getUsersByRole(@PathVariable String role) {
        try {
            Role userRole = Role.fromString(role);
            List<User> users = userService.getUsersByRole(userRole);
            return ResponseEntity.ok(ApiResponse.success(users, "Users by role retrieved"));
        } catch (IllegalArgumentException e) {
            return ResponseEntity.badRequest()
                .body(ApiResponse.error("Invalid role: " + role));
        }
    }

    /**
     * Get user statistics (Admin only)
     */
    @GetMapping("/stats")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<UserService.UserStats>> getUserStats() {
        UserService.UserStats stats = userService.getUserStats();
        return ResponseEntity.ok(ApiResponse.success(stats, "User statistics retrieved"));
    }

    /**
     * Convert DTO to Entity
     */
    private User convertToEntity(CreateUserDto dto) {
        Role role = Role.fromString(dto.getRole());
        return new User(dto.getUsername(), dto.getPassword(), dto.getEmail(), dto.getFullName(), role);
    }
}