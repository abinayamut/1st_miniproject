package com.example.library_management.service;

import com.example.library_management.entity.Book;
import com.example.library_management.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class BookService {
    
    @Autowired
    private BookRepository bookRepository;
    
    // Create new book
    public Book createBook(Book book) {
        if (bookRepository.findByIsbn(book.getIsbn()).isPresent()) {
            throw new RuntimeException("Book with ISBN " + book.getIsbn() + " already exists");
        }
        return bookRepository.save(book);
    }
    
    // Create sample books if they don't exist
    public void createSampleBooks() {
        if (bookRepository.count() == 0) {
            // Fiction books
            createBookIfNotExists("The Great Gatsby", "F. Scott Fitzgerald", "978-0-7432-7356-5", 
                                "Fiction", 5, "A classic American novel set in the Jazz Age");
            createBookIfNotExists("To Kill a Mockingbird", "Harper Lee", "978-0-06-112008-4", 
                                "Fiction", 4, "A gripping tale of racial injustice and childhood innocence");
            createBookIfNotExists("1984", "George Orwell", "978-0-452-28423-4", 
                                "Science Fiction", 6, "A dystopian social science fiction novel");
            createBookIfNotExists("Pride and Prejudice", "Jane Austen", "978-0-14-143951-8", 
                                "Romance", 3, "A romantic novel of manners");
            
            // Non-fiction books
            createBookIfNotExists("Sapiens", "Yuval Noah Harari", "978-0-06-231609-7", 
                                "History", 2, "A brief history of humankind");
            createBookIfNotExists("Educated", "Tara Westover", "978-0-399-59050-4", 
                                "Biography", 3, "A powerful memoir about education and family");
            
            // Technical books
            createBookIfNotExists("Clean Code", "Robert C. Martin", "978-0-13-235088-4", 
                                "Programming", 4, "A handbook of agile software craftsmanship");
            createBookIfNotExists("Java: The Complete Reference", "Herbert Schildt", "978-1-26-044070-2", 
                                "Programming", 5, "Comprehensive guide to Java programming");
            createBookIfNotExists("Design Patterns", "Gang of Four", "978-0-201-63361-0", 
                                "Programming", 2, "Elements of reusable object-oriented software");
            
            // Science books
            createBookIfNotExists("A Brief History of Time", "Stephen Hawking", "978-0-553-38016-3", 
                                "Science", 3, "From the big bang to black holes");
            createBookIfNotExists("The Selfish Gene", "Richard Dawkins", "978-0-19-929114-4", 
                                "Science", 2, "A view of evolution from the gene's perspective");
            
            System.out.println("Sample books created successfully!");
        }
    }
    
    private void createBookIfNotExists(String title, String author, String isbn, String genre, 
                                     Integer totalCopies, String description) {
        if (!bookRepository.findByIsbn(isbn).isPresent()) {
            Book book = new Book(title, author, isbn, genre, totalCopies);
            book.setDescription(description);
            book.setPublicationYear(2020); // Default year
            bookRepository.save(book);
        }
    }
    
    // Find book by ID
    public Optional<Book> findById(Long id) {
        return bookRepository.findById(id);
    }
    
    // Find book by ISBN
    public Optional<Book> findByIsbn(String isbn) {
        return bookRepository.findByIsbn(isbn);
    }
    
    // Get all books
    public List<Book> getAllBooks() {
        return bookRepository.findAll(Sort.by(Sort.Direction.ASC, "title"));
    }
    
    // Get available books
    public List<Book> getAvailableBooks() {
        return bookRepository.findAvailableBooks();
    }
    
    // Search books
    public List<Book> searchBooks(String keyword) {
        if (keyword == null || keyword.trim().isEmpty()) {
            return getAllBooks();
        }
        return bookRepository.searchBooks(keyword.trim());
    }
    
    // Find books by genre
    public List<Book> getBooksByGenre(String genre) {
        return bookRepository.findByGenreIgnoreCase(genre);
    }
    
    // Find books by author
    public List<Book> getBooksByAuthor(String author) {
        return bookRepository.findByAuthorContainingIgnoreCase(author);
    }
    
    // Get all genres
    public List<String> getAllGenres() {
        return bookRepository.findAllGenres();
    }
    
    // Update book
    public Book updateBook(Book book) {
        return bookRepository.save(book);
    }
    
    // Delete book with logging
    public void deleteBook(Long id) {
        // Log the book details before deletion
        Optional<Book> bookToDelete = bookRepository.findById(id);
        if (bookToDelete.isPresent()) {
            Book book = bookToDelete.get();
            System.out.println("=== BOOK DELETION LOG ===");
            System.out.println("Deleting Book ID: " + book.getId());
            System.out.println("Title: " + book.getTitle());
            System.out.println("Author: " + book.getAuthor());
            System.out.println("ISBN: " + book.getIsbn());
            System.out.println("Total Copies: " + book.getTotalCopies());
            System.out.println("Available Copies: " + book.getAvailableCopies());
            System.out.println("Deletion Time: " + java.time.LocalDateTime.now());
            System.out.println("========================");
            
            bookRepository.deleteById(id);
            
            System.out.println("Book successfully deleted from database!");
            System.out.println("Remaining books count: " + bookRepository.count());
        } else {
            System.out.println("Warning: Attempted to delete non-existent book with ID: " + id);
        }
    }
    
    // Get book statistics
    public BookStats getBookStats() {
        long totalBooks = bookRepository.getTotalBookCount();
        long totalCopies = bookRepository.getTotalCopiesCount();
        long availableCopies = bookRepository.getAvailableCopiesCount();
        long borrowedCopies = totalCopies - availableCopies;
        
        return new BookStats(totalBooks, totalCopies, availableCopies, borrowedCopies);
    }
    
    // Borrow a book
    public boolean borrowBook(Long bookId) {
        Optional<Book> bookOpt = bookRepository.findById(bookId);
        if (bookOpt.isPresent()) {
            Book book = bookOpt.get();
            if (book.borrowCopy()) {
                bookRepository.save(book);
                return true;
            }
        }
        return false;
    }
    
    // Return a book
    public void returnBook(Long bookId) {
        Optional<Book> bookOpt = bookRepository.findById(bookId);
        if (bookOpt.isPresent()) {
            Book book = bookOpt.get();
            book.returnCopy();
            bookRepository.save(book);
        }
    }
    
    // Inner class for book statistics
    public static class BookStats {
        private final long totalBooks;
        private final long totalCopies;
        private final long availableCopies;
        private final long borrowedCopies;
        
        public BookStats(long totalBooks, long totalCopies, long availableCopies, long borrowedCopies) {
            this.totalBooks = totalBooks;
            this.totalCopies = totalCopies;
            this.availableCopies = availableCopies;
            this.borrowedCopies = borrowedCopies;
        }
        
        // Getters
        public long getTotalBooks() { return totalBooks; }
        public long getTotalCopies() { return totalCopies; }
        public long getAvailableCopies() { return availableCopies; }
        public long getBorrowedCopies() { return borrowedCopies; }
    }

    // Additional methods for API support
    
    /**
     * Get book by ID
     */
    public Optional<Book> getBookById(Long id) {
        return bookRepository.findById(id);
    }
    
    /**
     * Get all books with pagination
     */
    public Page<Book> getAllBooksPageable(Pageable pageable) {
        return bookRepository.findAll(pageable);
    }
}