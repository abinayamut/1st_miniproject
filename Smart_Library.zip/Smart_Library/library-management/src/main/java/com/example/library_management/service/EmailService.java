package com.example.library_management.service;

import com.example.library_management.entity.User;
import com.example.library_management.entity.Book;
import com.example.library_management.entity.Transaction;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.mail.SimpleMailMessage;
import org.springframework.mail.javamail.JavaMailSender;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

/**
 * Service for sending email notifications
 */
@Service
public class EmailService {

    private static final Logger logger = LoggerFactory.getLogger(EmailService.class);

    @Autowired
    private JavaMailSender mailSender;

    @Value("${spring.mail.username:noreply@smartlibrary.com}")
    private String fromEmail;

    @Value("${app.email.enabled:false}")
    private boolean emailEnabled;

    /**
     * Send book overdue notification
     */
    @Async
    public void sendOverdueNotification(User user, Book book, Transaction transaction) {
        if (!emailEnabled) {
            logger.info("Email notification disabled. Would send overdue notification to: {}", user.getEmail());
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(user.getEmail());
            message.setSubject("Book Overdue - Smart Library");

            String content = String.format(
                "Dear %s,\n\n" +
                "This is a reminder that the following book is overdue:\n\n" +
                "Book: %s\n" +
                "Author: %s\n" +
                "Due Date: %s\n" +
                "Days Overdue: %d\n\n" +
                "Please return the book as soon as possible to avoid additional fines.\n\n" +
                "Thank you,\n" +
                "Smart Library Management System",
                user.getFullName(),
                book.getTitle(),
                book.getAuthor(),
                transaction.getDueDate().format(DateTimeFormatter.ofPattern("MMM dd, yyyy")),
                java.time.temporal.ChronoUnit.DAYS.between(transaction.getDueDate(), LocalDateTime.now())
            );

            message.setText(content);
            mailSender.send(message);
            
            logger.info("Overdue notification sent to: {}", user.getEmail());
            
        } catch (Exception e) {
            logger.error("Failed to send overdue notification to {}: {}", user.getEmail(), e.getMessage());
        }
    }

    /**
     * Send fine notification
     */
    @Async
    public void sendFineNotification(User user, double fineAmount, String reason) {
        if (!emailEnabled) {
            logger.info("Email notification disabled. Would send fine notification to: {}", user.getEmail());
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(user.getEmail());
            message.setSubject("Library Fine Notice - Smart Library");

            String content = String.format(
                "Dear %s,\n\n" +
                "A fine has been applied to your library account:\n\n" +
                "Fine Amount: $%.2f\n" +
                "Reason: %s\n" +
                "Date: %s\n\n" +
                "Please visit the library to pay your fine.\n\n" +
                "Thank you,\n" +
                "Smart Library Management System",
                user.getFullName(),
                fineAmount,
                reason,
                LocalDateTime.now().format(DateTimeFormatter.ofPattern("MMM dd, yyyy"))
            );

            message.setText(content);
            mailSender.send(message);
            
            logger.info("Fine notification sent to: {}", user.getEmail());
            
        } catch (Exception e) {
            logger.error("Failed to send fine notification to {}: {}", user.getEmail(), e.getMessage());
        }
    }

    /**
     * Send book reservation notification
     */
    @Async
    public void sendReservationNotification(User user, Book book) {
        if (!emailEnabled) {
            logger.info("Email notification disabled. Would send reservation notification to: {}", user.getEmail());
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(user.getEmail());
            message.setSubject("Book Available for Pickup - Smart Library");

            String content = String.format(
                "Dear %s,\n\n" +
                "Good news! The book you reserved is now available for pickup:\n\n" +
                "Book: %s\n" +
                "Author: %s\n\n" +
                "Please visit the library within 48 hours to collect your reserved book.\n\n" +
                "Thank you,\n" +
                "Smart Library Management System",
                user.getFullName(),
                book.getTitle(),
                book.getAuthor()
            );

            message.setText(content);
            mailSender.send(message);
            
            logger.info("Reservation notification sent to: {}", user.getEmail());
            
        } catch (Exception e) {
            logger.error("Failed to send reservation notification to {}: {}", user.getEmail(), e.getMessage());
        }
    }

    /**
     * Send welcome email to new users
     */
    @Async
    public void sendWelcomeEmail(User user, String temporaryPassword) {
        if (!emailEnabled) {
            logger.info("Email notification disabled. Would send welcome email to: {}", user.getEmail());
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(user.getEmail());
            message.setSubject("Welcome to Smart Library - Account Created");

            String content = String.format(
                "Dear %s,\n\n" +
                "Welcome to Smart Library Management System!\n\n" +
                "Your account has been successfully created:\n\n" +
                "Username: %s\n" +
                "Role: %s\n" +
                "Temporary Password: %s\n\n" +
                "Please log in to the system and change your password immediately.\n\n" +
                "System URL: http://localhost:8080/login\n\n" +
                "Thank you,\n" +
                "Smart Library Management System",
                user.getFullName(),
                user.getUsername(),
                user.getRole().getDisplayName(),
                temporaryPassword != null ? temporaryPassword : "[Password set by administrator]"
            );

            message.setText(content);
            mailSender.send(message);
            
            logger.info("Welcome email sent to: {}", user.getEmail());
            
        } catch (Exception e) {
            logger.error("Failed to send welcome email to {}: {}", user.getEmail(), e.getMessage());
        }
    }

    /**
     * Send book return reminder
     */
    @Async
    public void sendReturnReminder(User user, Book book, Transaction transaction) {
        if (!emailEnabled) {
            logger.info("Email notification disabled. Would send return reminder to: {}", user.getEmail());
            return;
        }

        try {
            SimpleMailMessage message = new SimpleMailMessage();
            message.setFrom(fromEmail);
            message.setTo(user.getEmail());
            message.setSubject("Book Return Reminder - Smart Library");

            String content = String.format(
                "Dear %s,\n\n" +
                "This is a friendly reminder that the following book is due soon:\n\n" +
                "Book: %s\n" +
                "Author: %s\n" +
                "Due Date: %s\n\n" +
                "Please return the book by the due date to avoid late fees.\n\n" +
                "Thank you,\n" +
                "Smart Library Management System",
                user.getFullName(),
                book.getTitle(),
                book.getAuthor(),
                transaction.getDueDate().format(DateTimeFormatter.ofPattern("MMM dd, yyyy"))
            );

            message.setText(content);
            mailSender.send(message);
            
            logger.info("Return reminder sent to: {}", user.getEmail());
            
        } catch (Exception e) {
            logger.error("Failed to send return reminder to {}: {}", user.getEmail(), e.getMessage());
        }
    }
}