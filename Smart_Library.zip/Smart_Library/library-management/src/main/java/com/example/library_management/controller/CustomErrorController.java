package com.example.library_management.controller;

import org.springframework.boot.web.servlet.error.ErrorController;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.RequestMapping;

import jakarta.servlet.RequestDispatcher;
import jakarta.servlet.http.HttpServletRequest;

@Controller
public class CustomErrorController implements ErrorController {
    
    @RequestMapping("/error")
    public String handleError(HttpServletRequest request, Model model) {
        Object status = request.getAttribute(RequestDispatcher.ERROR_STATUS_CODE);
        String errorMessage = "Something went wrong";
        String errorTitle = "Error";
        
        if (status != null) {
            Integer statusCode = Integer.valueOf(status.toString());
            
            switch (statusCode) {
                case 404:
                    errorTitle = "Page Not Found";
                    errorMessage = "The page you are looking for might have been removed, had its name changed, or is temporarily unavailable.";
                    model.addAttribute("errorCode", "404");
                    break;
                case 403:
                    errorTitle = "Access Denied";
                    errorMessage = "You don't have permission to access this resource.";
                    model.addAttribute("errorCode", "403");
                    break;
                case 500:
                    errorTitle = "Internal Server Error";
                    errorMessage = "We're experiencing some technical difficulties. Please try again later.";
                    model.addAttribute("errorCode", "500");
                    break;
                default:
                    errorTitle = "Error " + statusCode;
                    errorMessage = "An unexpected error occurred.";
                    model.addAttribute("errorCode", statusCode.toString());
                    break;
            }
        }
        
        model.addAttribute("errorTitle", errorTitle);
        model.addAttribute("errorMessage", errorMessage);
        
        return "error";
    }
}