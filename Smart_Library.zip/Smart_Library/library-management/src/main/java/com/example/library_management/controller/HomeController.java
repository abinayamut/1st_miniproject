package com.example.library_management.controller;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

@Controller
public class HomeController {

    @GetMapping("/")
    public String home(Model model) {
        model.addAttribute("title", "Smart Library Management System");
        model.addAttribute("message", "Welcome to the Smart Library Management System!");
        return "index";
    }

    @GetMapping("/home")
    public String homeAlternate(Model model) {
        return home(model);
    }

    @GetMapping("/books")
    public String books(@RequestParam(value = "search", required = false) String searchQuery,
                       @RequestParam(value = "author", required = false) String authorQuery,
                       @RequestParam(value = "category", required = false) String categoryQuery,
                       Model model) {
        model.addAttribute("title", "Browse Books - Smart Library");
        
        // Add query parameters to model for form persistence
        model.addAttribute("searchQuery", searchQuery);
        model.addAttribute("authorQuery", authorQuery);
        model.addAttribute("categoryQuery", categoryQuery);
        
        if ((searchQuery != null && !searchQuery.trim().isEmpty()) ||
            (authorQuery != null && !authorQuery.trim().isEmpty()) ||
            (categoryQuery != null && !categoryQuery.trim().isEmpty())) {
            
            // Perform search with multiple criteria
            model.addAttribute("searchResults", getFilteredBooks(searchQuery, authorQuery, categoryQuery));
        } else {
            model.addAttribute("books", getAllBooks());
        }
        
        return "books";
    }
    
    // Enhanced method to filter books by multiple criteria
    private java.util.List<java.util.Map<String, String>> getFilteredBooks(String searchQuery, String authorQuery, String categoryQuery) {
        java.util.List<java.util.Map<String, String>> allBooks = getAllBooksWithCategories();
        java.util.List<java.util.Map<String, String>> filteredBooks = new java.util.ArrayList<>();
        
        for (java.util.Map<String, String> book : allBooks) {
            boolean matches = true;
            
            // Filter by title
            if (searchQuery != null && !searchQuery.trim().isEmpty()) {
                matches = matches && book.get("title").toLowerCase().contains(searchQuery.toLowerCase());
            }
            
            // Filter by author
            if (authorQuery != null && !authorQuery.trim().isEmpty()) {
                matches = matches && book.get("author").toLowerCase().contains(authorQuery.toLowerCase());
            }
            
            // Filter by category
            if (categoryQuery != null && !categoryQuery.trim().isEmpty()) {
                matches = matches && book.get("category").equalsIgnoreCase(categoryQuery);
            }
            
            if (matches) {
                filteredBooks.add(book);
            }
        }
        
        return filteredBooks;
    }
    
    // Demo method to get all books with categories
    private java.util.List<java.util.Map<String, String>> getAllBooksWithCategories() {
        java.util.List<java.util.Map<String, String>> books = new java.util.ArrayList<>();
        books.add(createBookWithCategory("The Great Gatsby", "F. Scott Fitzgerald", "978-0743273565", "fiction"));
        books.add(createBookWithCategory("To Kill a Mockingbird", "Harper Lee", "978-0446310789", "fiction"));
        books.add(createBookWithCategory("1984", "George Orwell", "978-0451524935", "fiction"));
        books.add(createBookWithCategory("Pride and Prejudice", "Jane Austen", "978-0141439518", "fiction"));
        books.add(createBookWithCategory("Effective Java", "Joshua Bloch", "978-0134685991", "technology"));
        books.add(createBookWithCategory("Clean Code", "Robert Martin", "978-0132350884", "technology"));
        books.add(createBookWithCategory("Spring Boot in Action", "Craig Walls", "978-1617292545", "technology"));
        books.add(createBookWithCategory("Python Crash Course", "Eric Matthes", "978-1593279288", "technology"));
        books.add(createBookWithCategory("A Brief History of Time", "Stephen Hawking", "978-0553380163", "science"));
        books.add(createBookWithCategory("Sapiens", "Yuval Noah Harari", "978-0062316097", "history"));
        books.add(createBookWithCategory("Steve Jobs", "Walter Isaacson", "978-1451648539", "biography"));
        books.add(createBookWithCategory("The Lean Startup", "Eric Ries", "978-0307887894", "non-fiction"));
        return books;
    }
    
    // Demo method to get basic books (for backward compatibility)
    private java.util.List<java.util.Map<String, String>> getAllBooks() {
        java.util.List<java.util.Map<String, String>> books = new java.util.ArrayList<>();
        books.add(createBook("The Great Gatsby", "F. Scott Fitzgerald", "978-0743273565"));
        books.add(createBook("To Kill a Mockingbird", "Harper Lee", "978-0446310789"));
        books.add(createBook("1984", "George Orwell", "978-0451524935"));
        books.add(createBook("Pride and Prejudice", "Jane Austen", "978-0141439518"));
        books.add(createBook("Effective Java", "Joshua Bloch", "978-0134685991"));
        books.add(createBook("Clean Code", "Robert Martin", "978-0132350884"));
        books.add(createBook("Spring Boot in Action", "Craig Walls", "978-1617292545"));
        books.add(createBook("Python Crash Course", "Eric Matthes", "978-1593279288"));
        return books;
    }
    
    private java.util.Map<String, String> createBook(String title, String author, String isbn) {
        java.util.Map<String, String> book = new java.util.HashMap<>();
        book.put("title", title);
        book.put("author", author);
        book.put("isbn", isbn);
        return book;
    }
    
    private java.util.Map<String, String> createBookWithCategory(String title, String author, String isbn, String category) {
        java.util.Map<String, String> book = new java.util.HashMap<>();
        book.put("title", title);
        book.put("author", author);
        book.put("isbn", isbn);
        book.put("category", category);
        return book;
    }

    @GetMapping("/students")
    public String students(Model model) {
        model.addAttribute("title", "Students - Library Management");
        return "students";
    }

    // Student Login and Dashboard (redirects to main student controller)
    @GetMapping("/home/student-login")
    public String studentLogin(Model model) {
        model.addAttribute("title", "Student Login - Smart Library");
        return "student-login";
    }

    @GetMapping("/home/student-dashboard")
    public String studentDashboard(Model model) {
        model.addAttribute("title", "Student Dashboard - Smart Library");
        return "student-dashboard";
    }

    // Librarian Login and Dashboard (redirects to main librarian controller)
    @GetMapping("/home/librarian-login")
    public String librarianLogin(Model model) {
        model.addAttribute("title", "Librarian Login - Smart Library");
        return "librarian-login";
    }

    @GetMapping("/home/librarian-dashboard")
    public String librarianDashboard(Model model) {
        model.addAttribute("title", "Librarian Dashboard - Smart Library");
        return "librarian-dashboard";
    }
}
