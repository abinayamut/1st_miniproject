package com.example.library_management.entity;

import jakarta.persistence.*;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.AllArgsConstructor;
import java.time.LocalDateTime;

@Entity
@Table(name = "librarian_settings")
@Data
@NoArgsConstructor
@AllArgsConstructor
public class LibrarianSettings {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @Column(name = "user_id", nullable = false, unique = true)
    private Long userId;
    
    @Column(name = "full_name")
    private String fullName;
    
    @Column(name = "email")
    private String email;
    
    @Column(name = "phone")
    private String phone;
    
    @Column(name = "department")
    private String department;
    
    @Column(name = "bio", columnDefinition = "TEXT")
    private String bio;
    
    // Notification Settings
    @Column(name = "email_notifications", nullable = false)
    private Boolean emailNotifications = true;
    
    @Column(name = "sms_notifications", nullable = false)
    private Boolean smsNotifications = false;
    
    @Column(name = "overdue_alerts", nullable = false)
    private Boolean overdueAlerts = true;
    
    @Column(name = "new_book_alerts", nullable = false)
    private Boolean newBookAlerts = true;
    
    @Column(name = "system_alerts", nullable = false)
    private Boolean systemAlerts = true;
    
    // System Preferences
    @Column(name = "system_theme")
    private String systemTheme = "light";
    
    @Column(name = "language")
    private String language = "English";
    
    @Column(name = "records_per_page")
    private Integer recordsPerPage = 25;
    
    @Column(name = "date_format")
    private String dateFormat = "dd/MM/yyyy";
    
    // Working Hours Settings
    @Column(name = "working_hours")
    private String workingHours = "9:00 AM - 5:00 PM";
    
    @Column(name = "start_time")
    private String startTime = "09:00";
    
    @Column(name = "end_time")
    private String endTime = "17:00";
    
    @Column(name = "working_days")
    private String workingDays = "Monday,Tuesday,Wednesday,Thursday,Friday";
    
    @Column(name = "availability_status")
    private String availabilityStatus = "available";
    
    // Security Settings
    @Column(name = "two_factor_auth", nullable = false)
    private Boolean twoFactorAuth = false;
    
    @Column(name = "login_alerts", nullable = false)
    private Boolean loginAlerts = true;
    
    // Avatar
    @Column(name = "avatar_path")
    private String avatarPath;
    
    // Timestamps
    @Column(name = "created_at", nullable = false)
    private LocalDateTime createdAt;
    
    @Column(name = "updated_at", nullable = false)
    private LocalDateTime updatedAt;
    
    @PrePersist
    protected void onCreate() {
        createdAt = LocalDateTime.now();
        updatedAt = LocalDateTime.now();
    }
    
    @PreUpdate
    protected void onUpdate() {
        updatedAt = LocalDateTime.now();
    }
    
    // Helper methods for working days
    public String[] getWorkingDaysArray() {
        return workingDays != null ? workingDays.split(",") : new String[0];
    }
    
    public void setWorkingDaysArray(String[] days) {
        this.workingDays = String.join(",", days);
    }
    
    // Helper method to check if a specific day is a working day
    public boolean isWorkingDay(String day) {
        return workingDays != null && workingDays.contains(day);
    }
}