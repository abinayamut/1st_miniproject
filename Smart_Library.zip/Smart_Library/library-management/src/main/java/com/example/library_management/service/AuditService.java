package com.example.library_management.service;

import com.example.library_management.entity.AuditLog;
import com.example.library_management.entity.User;
import com.example.library_management.repository.AuditLogRepository;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.context.annotation.Lazy;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import jakarta.servlet.http.HttpServletRequest;
import java.time.LocalDateTime;
import java.util.List;

/**
 * Service for audit logging functionality
 */
@Service
public class AuditService {

    private static final Logger logger = LoggerFactory.getLogger(AuditService.class);

    private final AuditLogRepository auditLogRepository;

    /**
     * Self reference (lazy) to call async methods through Spring proxy instead of 'this'.
     */
    private final AuditService self;

    public AuditService(AuditLogRepository auditLogRepository, @Lazy AuditService self) {
        this.auditLogRepository = auditLogRepository;
        this.self = self;
    }

    /**
     * Log user action asynchronously
     */
    @Async
    public void logAction(String action, String entityType, String entityId, String details) {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            
            AuditLog auditLog = new AuditLog();
            auditLog.setAction(action);
            auditLog.setEntityType(entityType);
            auditLog.setEntityId(entityId);
            auditLog.setDetails(details);
            
            if (auth != null && auth.isAuthenticated() && !auth.getName().equals("anonymousUser")) {
                if (auth.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal userPrincipal) {
                    User user = userPrincipal.getUser();
                    auditLog.setUserId(user.getId());
                    auditLog.setUsername(user.getUsername());
                } else {
                    auditLog.setUsername(auth.getName());
                }
            }
            
            // Get request details
            ServletRequestAttributes attributes = (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attributes != null) {
                HttpServletRequest request = attributes.getRequest();
                auditLog.setIpAddress(getClientIpAddress(request));
                auditLog.setUserAgent(request.getHeader("User-Agent"));
            }
            
            auditLogRepository.save(auditLog);
            
        } catch (Exception e) {
            logger.error("Failed to log audit action: {}", e.getMessage(), e);
        }
    }

    /**
     * Log user creation
     */
    public void logUserCreation(User user, String createdBy) {
        // Call async via proxy to ensure @Async runs as expected
        self.logAction("CREATE_USER", "User", user.getId().toString(),
                String.format("User '%s' created with role '%s' by '%s'",
                        user.getUsername(), user.getRole(), createdBy));
    }

    /**
     * Log user login
     */
    public void logUserLogin(String username, String ipAddress) {
        AuditLog auditLog = new AuditLog();
        auditLog.setAction("USER_LOGIN");
        auditLog.setEntityType("User");
        auditLog.setUsername(username);
        auditLog.setIpAddress(ipAddress);
        auditLog.setDetails(String.format("User '%s' logged in successfully", username));
        
        auditLogRepository.save(auditLog);
    }

    /**
     * Log user logout
     */
    public void logUserLogout(String username) {
    // Call async via proxy
    self.logAction("USER_LOGOUT", "User", null,
        String.format("User '%s' logged out", username));
    }

    /**
     * Log book operations
     */
    public void logBookOperation(String action, Long bookId, String bookTitle, String details) {
    // Call async via proxy
    self.logAction(action, "Book", bookId.toString(),
        String.format("Book '%s' (ID: %d) - %s", bookTitle, bookId, details));
    }

    /**
     * Log transaction operations
     */
    public void logTransactionOperation(String action, Long transactionId, String details) {
        // Call async via proxy
        self.logAction(action, "Transaction", transactionId.toString(), details);
    }

    /**
     * Get audit logs for a user
     */
    public Page<AuditLog> getUserAuditLogs(Long userId, Pageable pageable) {
        return auditLogRepository.findByUserIdOrderByTimestampDesc(userId, pageable);
    }

    /**
     * Get audit logs by date range
     */
    public List<AuditLog> getAuditLogsByDateRange(LocalDateTime startDate, LocalDateTime endDate) {
        return auditLogRepository.findByTimestampBetween(startDate, endDate);
    }

    /**
     * Get all audit logs
     */
    public List<AuditLog> getAllAuditLogs() {
        return auditLogRepository.findAll();
    }

    /**
     * Get audit logs by action
     */
    public List<AuditLog> getAuditLogsByAction(String action) {
        return auditLogRepository.findByAction(action);
    }

    /**
     * Get audit logs by entity type
     */
    public List<AuditLog> getAuditLogsByEntityType(String entityType) {
        return auditLogRepository.findByEntityType(entityType);
    }

    /**
     * Get all distinct actions
     */
    public List<String> getAllActions() {
        return auditLogRepository.findAllActions();
    }

    /**
     * Get all distinct entity types
     */
    public List<String> getAllEntityTypes() {
        return auditLogRepository.findAllEntityTypes();
    }

    /**
     * Extract client IP address from request
     */
    private String getClientIpAddress(HttpServletRequest request) {
        String xForwardedFor = request.getHeader("X-Forwarded-For");
        if (xForwardedFor != null && !xForwardedFor.isEmpty() && !"unknown".equalsIgnoreCase(xForwardedFor)) {
            return xForwardedFor.split(",")[0].trim();
        }
        
        String xRealIp = request.getHeader("X-Real-IP");
        if (xRealIp != null && !xRealIp.isEmpty() && !"unknown".equalsIgnoreCase(xRealIp)) {
            return xRealIp;
        }
        
        return request.getRemoteAddr();
    }
}