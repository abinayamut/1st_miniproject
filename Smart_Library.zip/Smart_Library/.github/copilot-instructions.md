# Copilot Instructions for Smart_Library

## Project Architecture
This is a multi-role library management system built with **Spring Boot 3.5.7 + Java 21**, using role-based authentication (ADMIN/LIBRARIAN/STUDENT). The application follows a traditional MVC pattern with JPA/Hibernate for MySQL persistence.

**Core entities:** `User` (with Role enum), `Book`, `Transaction`, `Fine`, `LibrarianSettings`, `UserPoints`  
**Key directories:** `controller/` (role-based), `service/` (business logic), `entity/` (JPA entities), `config/` (security & data initialization)

## Critical Security Architecture
Authentication uses Spring Security with role-based access control:
- Routes: `/admin/**` → ADMIN, `/librarian/**` → LIBRARIAN, `/student/**` → STUDENT
- Custom success handler in `CustomAuthenticationSuccessHandler.java` redirects based on user role after login
- Form login at `/login` with custom failure handling via `CustomAuthenticationFailureHandler.java`
- Access denied page at `/403`

**Default credentials** (created by `DataInitializer.java`):
- Admin: `admin/admin123`
- Librarian: `librarian/librarian123` 
- Student: `student/student123`

## Database Configuration
**MySQL connection:** `jdbc:mysql://localhost:3306/studentdb_1` (see `application.properties`)
- Auto-DDL enabled (`spring.jpa.hibernate.ddl-auto=update`)
- Entities use `@PrePersist`/`@PreUpdate` for timestamp management (`User`, `Book`, `LibrarianSettings`)
- Sample data created on startup via `DataInitializer` (users, books, transactions)

## Controller Patterns
Controllers follow strict role-based separation:
```java
@Controller
@RequestMapping("/admin")  // Role-specific base path
public class AdminController {
    // Uses Authentication object to get current user details
    // Returns stats objects for dashboards (UserStats, BookStats)
}
```

Key controller responsibilities:
- `AdminController` - Full system management, user creation, book management
- `LibrarianController` - Book operations, student management
- `StudentController` - Personal dashboard, borrowing history
- `HomeController` - Public routes and book catalog browsing
- `AuthController` - Login/logout flow management

## Template Architecture
**Thymeleaf templates** in `src/main/resources/templates/`:
- Role-based naming: `{role}-{function}.html` (e.g., `admin-dashboard.html`)
- Shared fragments in `fragments/navbar.html` with role-specific navigation using `sec:authorize="hasRole('ADMIN')"`
- CSS variables for role-specific theming (e.g., `--admin-primary: hsl(15, 100%, 55%)`)
- Role-specific CSS files in `static/css/` with naming pattern `{role}-{function}-extra.css`

## Build & Run Workflows (Windows-Optimized)
**Project location:** `library-management/` subdirectory

**PowerShell (recommended):**
```powershell
.\run-app.ps1  # Sets JAVA_HOME to Eclipse Adoptium JDK 21, runs mvnw.cmd
```

**Maven wrapper commands:**
```cmd
.\mvnw.cmd clean package  # Build (use cmd for best compatibility)
.\mvnw.cmd spring-boot:run  # Run (port 8080)
.\mvnw.cmd test  # Run tests
```

**Critical:** Use Command Prompt for Maven commands if PowerShell gives path errors with spaces.

## Service Layer Patterns
Services contain business logic and return custom stats objects:
- `UserService.getUserStats()` returns user counts by role
- `BookService.getBookStats()` returns availability metrics  
- `TransactionService.createSampleTransactions()` seeds demo data
- `CustomUserDetailsService` handles Spring Security integration with custom `CustomUserPrincipal`

## Development Guidelines
- **New role:** Add controller + templates + update `SecurityConfig.java` role mappings
- **New entity:** Add JPA entity with `@PrePersist`/`@PreUpdate` + corresponding service/repository
- **UI components:** Use fragments pattern, maintain role-specific CSS theming
- **Static resources:** Place in `src/main/resources/static/css/` with role-specific naming pattern
- **Authentication:** Extract user details via `Authentication.getPrincipal()` cast to `CustomUserPrincipal`

## Key Dependencies
- Spring Boot 3.5.7, Spring Security, Spring Data JPA
- Thymeleaf for server-side rendering with Spring Security extras
- MySQL Connector (runtime), H2 available for testing
- Font Awesome icons, custom CSS with role-based color schemes
