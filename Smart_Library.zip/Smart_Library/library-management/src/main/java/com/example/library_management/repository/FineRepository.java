package com.example.library_management.repository;

import com.example.library_management.entity.Fine;
import com.example.library_management.entity.User;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import java.util.List;

@Repository
public interface FineRepository extends JpaRepository<Fine, Long> {
    List<Fine> findByUserAndPaidFalse(User user);
}
