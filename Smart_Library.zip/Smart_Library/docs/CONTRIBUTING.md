# Contributing to Smart Library

Thanks for your interest in contributing! This document explains the preferred workflow and how to run tests locally.

## Contributor Workflow
1. Fork the repository
2. Create a feature branch: `git checkout -b feat/my-feature`
3. Implement changes and include tests where appropriate
4. Run the build and tests locally
5. Push branch and open a Pull Request against `main`

## Code Style
- Java code: follow standard conventions (indentation, naming). Prefer small focused commits.
- Templates: use Thymeleaf idioms; avoid inline styles.
- Tests: JUnit + Spring Test where appropriate.

## Running Locally
Use the Maven wrapper for consistent builds:
```
# Build
mvnw.cmd clean package

# Run
mvnw.cmd spring-boot:run

# Test
mvnw.cmd test
```

If you run into PowerShell wrapper issues, use Command Prompt and the `mvnw.cmd` commands.

## Branch & PR Guidelines
- Target: `main`
- PR title should be descriptive and include issue number when present
- Include testing instructions in PR description

## Reporting Bugs
- Create an issue with steps to reproduce, expected vs actual behavior, and relevant logs.

## Security
- Do not commit secrets (DB credentials, API keys). Use environment variables or config files outside of VCS.

Thank you for contributing! 🎉
