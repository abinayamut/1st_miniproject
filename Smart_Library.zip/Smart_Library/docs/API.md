# API & Controller Reference

This file documents the main controller routes and the model attributes each view expects. Controllers are under `src/main/java/com/example/library_management/controller`.

## Public / Home
- `GET /` → `index.html`
  - Model: `title`, optionally `books` (from HomeController)

## Authentication
- `GET /login` → `login.html`
  - Model: `error`, `message`, `title`
- `POST /login` → (form login handled by Spring Security)
- `POST /logout` → handled by Spring Security or controllers that call `logout` mapping

## Admin (`/admin/**`)
- `GET /admin/dashboard` → `admin-dashboard.html`
  - Model: `currentUser`, `userStats`, `bookStats`, `transactions` as needed
- `GET /admin/books` → `admin-books.html` (list + manage books)
- `GET /admin/books/add` → `admin-add-book.html` (form)
- `POST /admin/books/add` → handles adding new books

## Librarian (`/librarian/**`)
- `GET /librarian/dashboard` → `librarian-dashboard.html`
  - Model: `currentUser`, `overdueList`, `activeLoans`
- `GET /librarian/issue` → `librarian-issue-book.html`
- `GET /librarian/return` → `librarian-return-book.html`

## Student (`/student/**`)
- `GET /student/login` → `student-login.html`
  - Model: `error`, `message`, `title`
- `GET /student/dashboard` → `student-dashboard.html`
  - Model: `title`, `currentUser`, `borrowedBooks`, `overdueBooks`, `reservedBooks`, `totalFines`, `recentActivity`
- `GET /student/books` → `student-books.html`
  - Model: `books` (available books)
- `GET /student/borrowed` → `student-borrowed.html`
  - Model: `borrowedTransactions` or similar
- `GET /student/history` → `student-history.html`
  - Model: `transactionHistory`
- `GET /student/fines` → `student-fines.html`
  - Model: `totalFines`, `fines` (list of fine items)

## API Notes
- Most views are server-rendered (Thymeleaf) and expect model attributes populated by controllers. Check each controller class for exact attribute keys.
- Transaction and Book operations are done via services (`BookService`, `TransactionService`) which wrap repository calls.

