package com.example.library_management.service;

import com.example.library_management.entity.Fine;
import com.example.library_management.entity.Transaction;
import com.example.library_management.repository.FineRepository;
import com.example.library_management.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class AutoFineScheduler {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private FineRepository fineRepository;

    // Run daily at 02:00
    @Scheduled(cron = "0 0 2 * * *")
    @Transactional
    public void applyAutoFines() {
        LocalDateTime now = LocalDateTime.now();
        List<Transaction> overdue = transactionRepository.findOverdueTransactions(now);
        for (Transaction t : overdue) {
            try {
                // calculate fine using existing method
                double fineAmount = t.calculateFine();
                t.setFineAmount(fineAmount);
                t.setStatus(Transaction.TransactionStatus.OVERDUE);
                transactionRepository.save(t);

                // create fine ledger entry
                Fine fine = new Fine(t, t.getUser(), fineAmount);
                fineRepository.save(fine);
            } catch (Exception ex) {
                // log and continue (avoid stopping scheduler)
                System.err.println("Error applying fine for transaction " + t.getId() + ": " + ex.getMessage());
            }
        }
    }
}
