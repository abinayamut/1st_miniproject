package com.example.library_management.repository;

import com.example.library_management.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.JpaSpecificationExecutor;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.util.List;
import java.util.Optional;

@Repository
public interface BookRepository extends JpaRepository<Book, Long>, JpaSpecificationExecutor<Book> {
    
    Optional<Book> findByIsbn(String isbn);
    
    List<Book> findByTitleContainingIgnoreCase(String title);
    
    List<Book> findByAuthorContainingIgnoreCase(String author);
    
    List<Book> findByGenreIgnoreCase(String genre);
    
    List<Book> findByAvailableCopiesGreaterThan(Integer count);
    
    @Query("SELECT b FROM Book b WHERE b.title LIKE %:keyword% OR b.author LIKE %:keyword% OR b.genre LIKE %:keyword%")
    List<Book> searchBooks(@Param("keyword") String keyword);
    
    // Additional search method for API
    List<Book> findByTitleContainingIgnoreCaseOrAuthorContainingIgnoreCase(String title, String author);
    
    @Query("SELECT DISTINCT b.genre FROM Book b ORDER BY b.genre")
    List<String> findAllGenres();
    
    @Query("SELECT b FROM Book b WHERE b.availableCopies > 0")
    List<Book> findAvailableBooks();

    // Content-based recommendation helper: find books by genre and order by borrow popularity
    @Query("SELECT b FROM Book b WHERE b.genre IN :genres AND b.availableCopies > 0")
    List<Book> findByGenreInAvailable(@Param("genres") List<String> genres);
    
    @Query("SELECT COUNT(b) FROM Book b")
    long getTotalBookCount();
    
    @Query("SELECT SUM(b.totalCopies) FROM Book b")
    long getTotalCopiesCount();
    
    @Query("SELECT SUM(b.availableCopies) FROM Book b")
    long getAvailableCopiesCount();
}