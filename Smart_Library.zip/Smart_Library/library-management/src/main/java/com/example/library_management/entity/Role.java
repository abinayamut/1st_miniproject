package com.example.library_management.entity;

/**
 * Role enumeration for user types in the Smart Library system
 */
public enum Role {
    ADMIN("ADMIN", "Administrator"),
    LIBRARIAN("LIBRARIAN", "Librarian"),
    STUDENT("STUDENT", "Student");

    private final String roleName;
    private final String displayName;

    Role(String roleName, String displayName) {
        this.roleName = roleName;
        this.displayName = displayName;
    }

    public String getRoleName() {
        return roleName;
    }

    public String getDisplayName() {
        return displayName;
    }

    /**
     * Get role with ROLE_ prefix for Spring Security
     */
    public String getAuthorityName() {
        return "ROLE_" + roleName;
    }

    /**
     * Create Role from string value
     */
    public static Role fromString(String roleString) {
        if (roleString == null || roleString.trim().isEmpty()) {
            throw new IllegalArgumentException("Role string cannot be null or empty");
        }
        
        String cleanRole = roleString.toUpperCase().replace("ROLE_", "");
        
        for (Role role : Role.values()) {
            if (role.roleName.equals(cleanRole)) {
                return role;
            }
        }
        
        throw new IllegalArgumentException("Invalid role: " + roleString);
    }

    @Override
    public String toString() {
        return displayName;
    }
}