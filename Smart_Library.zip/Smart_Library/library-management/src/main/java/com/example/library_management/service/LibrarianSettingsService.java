package com.example.library_management.service;

import com.example.library_management.entity.LibrarianSettings;
import com.example.library_management.entity.User;
import com.example.library_management.repository.LibrarianSettingsRepository;
import com.example.library_management.repository.UserRepository;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Slf4j
@Transactional
public class LibrarianSettingsService {
    
    @Autowired
    private LibrarianSettingsRepository librarianSettingsRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    /**
     * Get settings for a librarian by user ID
     */
    public LibrarianSettings getSettingsByUserId(Long userId) {
        Optional<LibrarianSettings> settings = librarianSettingsRepository.findByUserId(userId);
        
        if (settings.isPresent()) {
            return settings.get();
        } else {
            // Create default settings if none exist
            return createDefaultSettings(userId);
        }
    }
    
    /**
     * Get settings for a librarian by username
     */
    public LibrarianSettings getSettingsByUsername(String username) {
        Optional<User> user = userRepository.findByUsername(username);
        if (user.isPresent()) {
            return getSettingsByUserId(user.get().getId());
        }
        throw new RuntimeException("User not found: " + username);
    }
    
    /**
     * Save or update librarian settings
     */
    public LibrarianSettings saveSettings(LibrarianSettings settings) {
        log.info("Saving settings for user ID: {}", settings.getUserId());
        return librarianSettingsRepository.save(settings);
    }
    
    /**
     * Update settings for a specific user
     */
    public LibrarianSettings updateSettings(Long userId, LibrarianSettings updatedSettings) {
        LibrarianSettings existingSettings = getSettingsByUserId(userId);
        
        // Update basic profile information
        if (updatedSettings.getFullName() != null) {
            existingSettings.setFullName(updatedSettings.getFullName());
        }
        if (updatedSettings.getEmail() != null) {
            existingSettings.setEmail(updatedSettings.getEmail());
        }
        if (updatedSettings.getPhone() != null) {
            existingSettings.setPhone(updatedSettings.getPhone());
        }
        if (updatedSettings.getDepartment() != null) {
            existingSettings.setDepartment(updatedSettings.getDepartment());
        }
        if (updatedSettings.getBio() != null) {
            existingSettings.setBio(updatedSettings.getBio());
        }
        
        // Update notification settings
        if (updatedSettings.getEmailNotifications() != null) {
            existingSettings.setEmailNotifications(updatedSettings.getEmailNotifications());
        }
        if (updatedSettings.getSmsNotifications() != null) {
            existingSettings.setSmsNotifications(updatedSettings.getSmsNotifications());
        }
        if (updatedSettings.getOverdueAlerts() != null) {
            existingSettings.setOverdueAlerts(updatedSettings.getOverdueAlerts());
        }
        if (updatedSettings.getNewBookAlerts() != null) {
            existingSettings.setNewBookAlerts(updatedSettings.getNewBookAlerts());
        }
        if (updatedSettings.getSystemAlerts() != null) {
            existingSettings.setSystemAlerts(updatedSettings.getSystemAlerts());
        }
        
        // Update system preferences
        if (updatedSettings.getSystemTheme() != null) {
            existingSettings.setSystemTheme(updatedSettings.getSystemTheme());
        }
        if (updatedSettings.getLanguage() != null) {
            existingSettings.setLanguage(updatedSettings.getLanguage());
        }
        if (updatedSettings.getRecordsPerPage() != null) {
            existingSettings.setRecordsPerPage(updatedSettings.getRecordsPerPage());
        }
        if (updatedSettings.getDateFormat() != null) {
            existingSettings.setDateFormat(updatedSettings.getDateFormat());
        }
        
        // Update working hours
        if (updatedSettings.getWorkingHours() != null) {
            existingSettings.setWorkingHours(updatedSettings.getWorkingHours());
        }
        if (updatedSettings.getStartTime() != null) {
            existingSettings.setStartTime(updatedSettings.getStartTime());
        }
        if (updatedSettings.getEndTime() != null) {
            existingSettings.setEndTime(updatedSettings.getEndTime());
        }
        if (updatedSettings.getWorkingDays() != null) {
            existingSettings.setWorkingDays(updatedSettings.getWorkingDays());
        }
        if (updatedSettings.getAvailabilityStatus() != null) {
            existingSettings.setAvailabilityStatus(updatedSettings.getAvailabilityStatus());
        }
        
        // Update security settings
        if (updatedSettings.getTwoFactorAuth() != null) {
            existingSettings.setTwoFactorAuth(updatedSettings.getTwoFactorAuth());
        }
        if (updatedSettings.getLoginAlerts() != null) {
            existingSettings.setLoginAlerts(updatedSettings.getLoginAlerts());
        }
        
        // Update avatar path
        if (updatedSettings.getAvatarPath() != null) {
            existingSettings.setAvatarPath(updatedSettings.getAvatarPath());
        }
        
        return saveSettings(existingSettings);
    }
    
    /**
     * Create default settings for a new user
     */
    private LibrarianSettings createDefaultSettings(Long userId) {
        log.info("Creating default settings for user ID: {}", userId);
        
        // Get user information
        Optional<User> user = userRepository.findById(userId);
        
        LibrarianSettings defaultSettings = new LibrarianSettings();
        defaultSettings.setUserId(userId);
        
        if (user.isPresent()) {
            defaultSettings.setFullName(user.get().getFullName());
            defaultSettings.setEmail(user.get().getEmail());
        }
        
        // Set default values
        defaultSettings.setDepartment("Information Services");
        defaultSettings.setEmailNotifications(true);
        defaultSettings.setSmsNotifications(false);
        defaultSettings.setOverdueAlerts(true);
        defaultSettings.setNewBookAlerts(true);
        defaultSettings.setSystemAlerts(true);
        defaultSettings.setSystemTheme("light");
        defaultSettings.setLanguage("English");
        defaultSettings.setRecordsPerPage(25);
        defaultSettings.setDateFormat("dd/MM/yyyy");
        defaultSettings.setWorkingHours("9:00 AM - 5:00 PM");
        defaultSettings.setStartTime("09:00");
        defaultSettings.setEndTime("17:00");
        defaultSettings.setWorkingDays("Monday,Tuesday,Wednesday,Thursday,Friday");
        defaultSettings.setAvailabilityStatus("available");
        defaultSettings.setTwoFactorAuth(false);
        defaultSettings.setLoginAlerts(true);
        
        return saveSettings(defaultSettings);
    }
    
    /**
     * Delete settings for a user
     */
    public void deleteSettings(Long userId) {
        log.info("Deleting settings for user ID: {}", userId);
        librarianSettingsRepository.deleteByUserId(userId);
    }
    
    /**
     * Get all librarians with email notifications enabled
     */
    public List<LibrarianSettings> getLibrariansWithEmailNotifications() {
        return librarianSettingsRepository.findAllWithEmailNotificationsEnabled();
    }
    
    /**
     * Get all librarians with SMS notifications enabled
     */
    public List<LibrarianSettings> getLibrariansWithSmsNotifications() {
        return librarianSettingsRepository.findAllWithSmsNotificationsEnabled();
    }
    
    /**
     * Get all librarians with overdue alerts enabled
     */
    public List<LibrarianSettings> getLibrariansWithOverdueAlerts() {
        return librarianSettingsRepository.findAllWithOverdueAlertsEnabled();
    }
    
    /**
     * Get librarians by department
     */
    public List<LibrarianSettings> getLibrariansByDepartment(String department) {
        return librarianSettingsRepository.findByDepartment(department);
    }
    
    /**
     * Get available librarians
     */
    public List<LibrarianSettings> getAvailableLibrarians() {
        return librarianSettingsRepository.findByAvailabilityStatus("available");
    }
    
    /**
     * Get librarians with two-factor authentication enabled
     */
    public List<LibrarianSettings> getLibrariansWithTwoFactorAuth() {
        return librarianSettingsRepository.findAllWithTwoFactorAuthEnabled();
    }
    
    /**
     * Check if settings exist for a user
     */
    public boolean settingsExist(Long userId) {
        return librarianSettingsRepository.existsByUserId(userId);
    }
    
    /**
     * Get theme statistics
     */
    public Long getThemeUsageCount(String theme) {
        return librarianSettingsRepository.countBySystemTheme(theme);
    }
}