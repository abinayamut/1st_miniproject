package com.example.library_management.service;

import com.example.library_management.entity.Book;
import com.example.library_management.entity.Transaction;
import com.example.library_management.entity.User;
import com.example.library_management.repository.BookRepository;
import com.example.library_management.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.*;

@Service
public class RecommendationService {

    @Autowired
    private TransactionRepository transactionRepository;

    @Autowired
    private BookRepository bookRepository;

    /**
     * Very small content-based recommender: use user's top genres and return available books
     */
    public List<Book> getRecommendationsForUser(User user, int limit) {
        List<Transaction> tx = transactionRepository.findByUser(user);
        if (tx == null || tx.isEmpty()) {
            // fallback: popular books
            return bookRepository.findAvailableBooks().subList(0, Math.min(limit, bookRepository.findAvailableBooks().size()));
        }

        Map<String, Integer> genreCount = new HashMap<>();
        for (Transaction t : tx) {
            if (t.getBook() != null && t.getBook().getGenre() != null) {
                genreCount.put(t.getBook().getGenre(), genreCount.getOrDefault(t.getBook().getGenre(), 0) + 1);
            }
        }

        // sort genres by count
        List<String> genres = new ArrayList<>(genreCount.keySet());
        genres.sort((a, b) -> genreCount.get(b) - genreCount.get(a));

        if (genres.isEmpty()) {
            return bookRepository.findAvailableBooks().subList(0, Math.min(limit, bookRepository.findAvailableBooks().size()));
        }

        // Query candidate books by top genres
        List<String> topGenres = genres.subList(0, Math.min(3, genres.size()));
        List<Book> candidates = bookRepository.findByGenreInAvailable(topGenres);

        // Simple scoring: genre match priority then by title
        candidates.sort(Comparator.comparing(Book::getTitle));

        return candidates.subList(0, Math.min(limit, candidates.size()));
    }
}
