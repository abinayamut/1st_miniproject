package com.example.library_management.controller;

import com.example.library_management.entity.Book;
import com.example.library_management.entity.User;
import com.example.library_management.service.BookService;
import com.example.library_management.service.UserService;
import com.example.library_management.service.CustomUserDetailsService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.validation.BindingResult;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.io.File;
import java.io.IOException;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserService userService;
    
    @Autowired
    private BookService bookService;

    @GetMapping("/dashboard")
    public String adminDashboard(Model model, Authentication authentication) {
        model.addAttribute("title", "Admin Dashboard - Smart Library");
        
        // Get current user details
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal) {
            CustomUserDetailsService.CustomUserPrincipal userPrincipal = 
                (CustomUserDetailsService.CustomUserPrincipal) authentication.getPrincipal();
            model.addAttribute("currentUser", userPrincipal.getUser());
        }
        
        // Get statistics for dashboard
        UserService.UserStats userStats = userService.getUserStats();
        BookService.BookStats bookStats = bookService.getBookStats();
        
        model.addAttribute("userStats", userStats);
        model.addAttribute("bookStats", bookStats);
        
        // Get recent users and books
        model.addAttribute("recentUsers", userService.getAllUsers().stream().limit(5).toList());
        model.addAttribute("recentBooks", bookService.getAllBooks().stream().limit(5).toList());
        
        return "admin-dashboard";
    }

    // User Management
    @GetMapping("/users")
    public String manageUsers(Model model) {
        model.addAttribute("title", "User Management - Smart Library");
        model.addAttribute("users", userService.getAllUsers());
        model.addAttribute("newUser", new User());
        return "admin-users";
    }

    @PostMapping("/users/create")
    public String createUser(@ModelAttribute("newUser") User user, 
                           BindingResult result, RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            redirectAttributes.addFlashAttribute("error", "Please fix the validation errors.");
            return "redirect:/admin/users";
        }
        
        try {
            userService.createUser(user);
            redirectAttributes.addFlashAttribute("success", "User created successfully!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        
        return "redirect:/admin/users";
    }

    @PostMapping("/users/{id}/toggle-status")
    @ResponseBody
    public ResponseEntity<?> toggleUserStatus(@PathVariable Long id) {
        try {
            Optional<User> userOpt = userService.findById(id);
            if (userOpt.isPresent()) {
                User user = userOpt.get();
                if (user.isActive()) {
                    userService.deactivateUser(id);
                } else {
                    userService.activateUser(id);
                }
                return ResponseEntity.ok().build();
            } else {
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @DeleteMapping("/users/{id}")
    @ResponseBody
    public ResponseEntity<?> deleteUser(@PathVariable Long id) {
        try {
            userService.deleteUser(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    // Book Management
    @GetMapping("/books")
    public String manageBooks(Model model, @RequestParam(required = false) String search) {
        model.addAttribute("title", "Book Management - Smart Library");
        
        List<Book> books;
        if (search != null && !search.trim().isEmpty()) {
            books = bookService.searchBooks(search);
            model.addAttribute("searchQuery", search);
        } else {
            books = bookService.getAllBooks();
        }
        
        model.addAttribute("books", books);
        model.addAttribute("newBook", new Book());
        model.addAttribute("genres", bookService.getAllGenres());
        
        return "admin-books";
    }

    @PostMapping("/books/create")
    public String createBook(@ModelAttribute("newBook") Book book, 
                           BindingResult result, RedirectAttributes redirectAttributes) {
        if (result.hasErrors()) {
            redirectAttributes.addFlashAttribute("error", "Please fix the validation errors.");
            return "redirect:/admin/books";
        }
        
        try {
            bookService.createBook(book);
            redirectAttributes.addFlashAttribute("success", "Book added successfully!");
        } catch (RuntimeException e) {
            redirectAttributes.addFlashAttribute("error", e.getMessage());
        }
        
        return "redirect:/admin/books";
    }

    @PutMapping("/books/{id}")
    @ResponseBody
    public ResponseEntity<?> updateBook(@PathVariable Long id, @RequestBody Book book) {
        try {
            book.setId(id);
            Book updatedBook = bookService.updateBook(book);
            return ResponseEntity.ok(updatedBook);
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @DeleteMapping("/books/{id}")
    @ResponseBody
    public ResponseEntity<?> deleteBook(@PathVariable Long id) {
        try {
            bookService.deleteBook(id);
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    // Clear all books (truncate)
    @PostMapping("/books/clear")
    @ResponseBody
    public ResponseEntity<?> clearAllBooks() {
        try {
            List<Book> allBooks = bookService.getAllBooks();
            for (Book book : allBooks) {
                bookService.deleteBook(book.getId());
            }
            return ResponseEntity.ok().build();
        } catch (Exception e) {
            return ResponseEntity.badRequest().build();
        }
    }

    @GetMapping("/reports")
    public String viewReports(Model model) {
        model.addAttribute("title", "Reports & Analytics - Smart Library");
        
        // Add statistics
        model.addAttribute("userStats", userService.getUserStats());
        model.addAttribute("bookStats", bookService.getBookStats());
        
        // Add data for charts
        model.addAttribute("genres", bookService.getAllGenres());
        model.addAttribute("users", userService.getAllUsers());
        model.addAttribute("books", bookService.getAllBooks());
        
        return "admin-reports";
    }

    // Add Book page controller methods
    @GetMapping("/books/add")
    public String showAddBookPage(Model model) {
        model.addAttribute("title", "Add New Book - Smart Library");
        model.addAttribute("book", new Book());
        return "admin-add-book";
    }

    @PostMapping("/books/add")
    public String addBook(@ModelAttribute("book") Book book, 
                         BindingResult result, 
                         RedirectAttributes redirectAttributes,
                         @RequestParam(value = "coverImage", required = false) MultipartFile coverImageFile) {
        
        // Validate required fields
        if (book.getTitle() == null || book.getTitle().trim().isEmpty()) {
            result.rejectValue("title", "error.book", "Title is required");
        }
        if (book.getAuthor() == null || book.getAuthor().trim().isEmpty()) {
            result.rejectValue("author", "error.book", "Author is required");
        }
        if (book.getGenre() == null || book.getGenre().trim().isEmpty()) {
            result.rejectValue("genre", "error.book", "Category is required");
        }
        if (book.getTotalCopies() == null || book.getTotalCopies() < 1) {
            result.rejectValue("totalCopies", "error.book", "Total copies must be at least 1");
        }
        
        if (result.hasErrors()) {
            redirectAttributes.addFlashAttribute("error", "Please fix the validation errors and try again.");
            return "redirect:/admin/books/add";
        }
        
        try {
            // Handle file upload
            if (coverImageFile != null && !coverImageFile.isEmpty()) {
                String fileName = saveUploadedFile(coverImageFile);
                book.setCoverImagePath(fileName);
            }
            
            // Set available copies equal to total copies for new book
            book.setAvailableCopies(book.getTotalCopies());
            
            // Set creation timestamp
            book.setCreatedAt(java.time.LocalDateTime.now());
            book.setUpdatedAt(java.time.LocalDateTime.now());
            
            // Save the book
            Book savedBook = bookService.createBook(book);
            
            redirectAttributes.addFlashAttribute("success", 
                "Book '" + savedBook.getTitle() + "' has been added successfully!");
            
            return "redirect:/admin/books";
            
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("error", 
                "Error adding book: " + e.getMessage());
            return "redirect:/admin/books/add";
        }
    }
    
    private String saveUploadedFile(MultipartFile file) throws IOException {
        if (file.isEmpty()) {
            return null;
        }
        
        // Create uploads directory if it doesn't exist
        String uploadDir = "src/main/resources/static/uploads/covers/";
        File directory = new File(uploadDir);
        if (!directory.exists()) {
            directory.mkdirs();
        }
        
        // Generate unique filename
        String originalFilename = file.getOriginalFilename();
        String extension = originalFilename != null && originalFilename.contains(".") 
            ? originalFilename.substring(originalFilename.lastIndexOf(".")) 
            : "";
        String filename = System.currentTimeMillis() + "_" + UUID.randomUUID().toString() + extension;
        
        // Save file
        String filePath = uploadDir + filename;
        file.transferTo(new File(filePath));
        
        // Return relative path for storing in database
        return "/uploads/covers/" + filename;
    }
    
    // REST API endpoint for adding books (AJAX support)
    @PostMapping("/api/books/add")
    @ResponseBody
    public ResponseEntity<?> addBookApi(@RequestParam("title") String title,
                                       @RequestParam("author") String author,
                                       @RequestParam("genre") String genre,
                                       @RequestParam("totalCopies") Integer totalCopies,
                                       @RequestParam(value = "isbn", required = false) String isbn,
                                       @RequestParam(value = "publisher", required = false) String publisher,
                                       @RequestParam(value = "publicationYear", required = false) Integer publicationYear,
                                       @RequestParam(value = "pages", required = false) Integer pages,
                                       @RequestParam(value = "description", required = false) String description,
                                       @RequestParam(value = "coverImage", required = false) MultipartFile coverImageFile) {
        
        try {
            // Validate required fields
            if (title == null || title.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("{\"error\": \"Title is required\"}");
            }
            if (author == null || author.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("{\"error\": \"Author is required\"}");
            }
            if (genre == null || genre.trim().isEmpty()) {
                return ResponseEntity.badRequest().body("{\"error\": \"Category is required\"}");
            }
            if (totalCopies == null || totalCopies < 1) {
                return ResponseEntity.badRequest().body("{\"error\": \"Total copies must be at least 1\"}");
            }
            
            // Create new book object
            Book book = new Book();
            book.setTitle(title.trim());
            book.setAuthor(author.trim());
            book.setGenre(genre.trim());
            book.setTotalCopies(totalCopies);
            book.setAvailableCopies(totalCopies);
            
            // Set optional fields
            if (isbn != null && !isbn.trim().isEmpty()) {
                book.setIsbn(isbn.trim());
            }
            if (publisher != null && !publisher.trim().isEmpty()) {
                book.setPublisher(publisher.trim());
            }
            if (publicationYear != null) {
                book.setPublicationYear(publicationYear);
            }
            if (pages != null) {
                book.setPages(pages);
            }
            if (description != null && !description.trim().isEmpty()) {
                book.setDescription(description.trim());
            }
            
            // Handle file upload
            if (coverImageFile != null && !coverImageFile.isEmpty()) {
                String fileName = saveUploadedFile(coverImageFile);
                book.setCoverImagePath(fileName);
            }
            
            // Save the book
            Book savedBook = bookService.createBook(book);
            
            return ResponseEntity.ok().body("{\"success\": \"Book '" + savedBook.getTitle() + "' has been added successfully!\", \"bookId\": " + savedBook.getId() + "}");
            
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("{\"error\": \"Error adding book: " + e.getMessage() + "\"}");
        }
    }
}
