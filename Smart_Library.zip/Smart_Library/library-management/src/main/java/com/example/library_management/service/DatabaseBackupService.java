package com.example.library_management.service;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;
import java.util.concurrent.TimeUnit;

/**
 * Service for database backup and restore operations
 */
@Service
public class DatabaseBackupService {

    private static final Logger logger = LoggerFactory.getLogger(DatabaseBackupService.class);

    @Value("${spring.datasource.url}")
    private String databaseUrl;

    @Value("${spring.datasource.username}")
    private String databaseUsername;

    @Value("${spring.datasource.password}")
    private String databasePassword;

    @Value("${app.backup.enabled:false}")
    private boolean backupEnabled;

    @Value("${app.backup.directory:./backups}")
    private String backupDirectory;

    @Value("${app.backup.max-files:10}")
    private int maxBackupFiles;

    /**
     * Create a database backup
     */
    public String createBackup() throws IOException, InterruptedException {
        if (!backupEnabled) {
            logger.info("Database backup is disabled");
            return null;
        }

        // Create backup directory if it doesn't exist
        Path backupPath = Paths.get(backupDirectory);
        if (!Files.exists(backupPath)) {
            Files.createDirectories(backupPath);
        }

        // Generate backup filename with timestamp
        String timestamp = LocalDateTime.now().format(DateTimeFormatter.ofPattern("yyyyMMdd_HHmmss"));
        String backupFileName = String.format("library_backup_%s.sql", timestamp);
        String backupFilePath = Paths.get(backupDirectory, backupFileName).toString();

        try {
            if (databaseUrl.contains("mysql")) {
                return createMySQLBackup(backupFilePath);
            } else if (databaseUrl.contains("h2")) {
                return createH2Backup(backupFilePath);
            } else {
                logger.warn("Unsupported database type for backup: {}", databaseUrl);
                return null;
            }
        } catch (Exception e) {
            logger.error("Failed to create database backup: {}", e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Create MySQL database backup
     */
    private String createMySQLBackup(String backupFilePath) throws IOException, InterruptedException {
        // Extract database name from URL
        String databaseName = extractDatabaseName(databaseUrl);
        
        ProcessBuilder processBuilder = new ProcessBuilder(
            "mysqldump",
            "--host=localhost",
            "--user=" + databaseUsername,
            "--password=" + databasePassword,
            "--single-transaction",
            "--routines",
            "--triggers",
            databaseName
        );

        processBuilder.redirectOutput(new File(backupFilePath));
        processBuilder.redirectErrorStream(true);

        Process process = processBuilder.start();
        boolean finished = process.waitFor(5, TimeUnit.MINUTES);

        if (!finished) {
            process.destroyForcibly();
            throw new RuntimeException("Backup process timed out");
        }

        if (process.exitValue() != 0) {
            throw new RuntimeException("Backup process failed with exit code: " + process.exitValue());
        }

        logger.info("MySQL backup created successfully: {}", backupFilePath);
        
        // Clean up old backup files
        cleanupOldBackups();
        
        return backupFilePath;
    }

    /**
     * Create H2 database backup (simplified approach)
     */
    private String createH2Backup(String backupFilePath) throws IOException {
        // For H2, we'll create a simple SQL export
        // In a real implementation, you would use H2's SCRIPT command
        logger.info("H2 backup created (simplified): {}", backupFilePath);
        
        // Create a placeholder file for demonstration
        Files.write(Paths.get(backupFilePath), 
                   ("-- H2 Database Backup\n-- Created: " + LocalDateTime.now() + "\n").getBytes());
        
        return backupFilePath;
    }

    /**
     * Restore database from backup
     */
    public void restoreBackup(String backupFilePath) throws IOException, InterruptedException {
        if (!Files.exists(Paths.get(backupFilePath))) {
            throw new IOException("Backup file not found: " + backupFilePath);
        }

        try {
            if (databaseUrl.contains("mysql")) {
                restoreMySQLBackup(backupFilePath);
            } else if (databaseUrl.contains("h2")) {
                restoreH2Backup(backupFilePath);
            } else {
                throw new UnsupportedOperationException("Unsupported database type for restore: " + databaseUrl);
            }
        } catch (Exception e) {
            logger.error("Failed to restore database backup: {}", e.getMessage(), e);
            throw e;
        }
    }

    /**
     * Restore MySQL database
     */
    private void restoreMySQLBackup(String backupFilePath) throws IOException, InterruptedException {
        String databaseName = extractDatabaseName(databaseUrl);
        
        ProcessBuilder processBuilder = new ProcessBuilder(
            "mysql",
            "--host=localhost",
            "--user=" + databaseUsername,
            "--password=" + databasePassword,
            databaseName
        );

        processBuilder.redirectInput(new File(backupFilePath));

        Process process = processBuilder.start();
        boolean finished = process.waitFor(5, TimeUnit.MINUTES);

        if (!finished) {
            process.destroyForcibly();
            throw new RuntimeException("Restore process timed out");
        }

        if (process.exitValue() != 0) {
            throw new RuntimeException("Restore process failed with exit code: " + process.exitValue());
        }

        logger.info("MySQL database restored successfully from: {}", backupFilePath);
    }

    /**
     * Restore H2 database (simplified)
     */
    private void restoreH2Backup(String backupFilePath) {
        logger.info("H2 database restore (simplified) from: {}", backupFilePath);
        // Implementation would depend on H2's RUNSCRIPT command
    }

    /**
     * Scheduled backup (runs daily at 2 AM)
     */
    @Scheduled(cron = "0 0 2 * * ?")
    public void scheduledBackup() {
        if (backupEnabled) {
            try {
                logger.info("Starting scheduled database backup");
                String backupFile = createBackup();
                if (backupFile != null) {
                    logger.info("Scheduled backup completed: {}", backupFile);
                }
            } catch (Exception e) {
                logger.error("Scheduled backup failed: {}", e.getMessage(), e);
            }
        }
    }

    /**
     * Get list of available backup files
     */
    public File[] getAvailableBackups() throws IOException {
        Path backupPath = Paths.get(backupDirectory);
        if (!Files.exists(backupPath)) {
            return new File[0];
        }

        File backupDir = backupPath.toFile();
        File[] backupFiles = backupDir.listFiles((dir, name) -> name.endsWith(".sql"));
        
        if (backupFiles == null) {
            return new File[0];
        }

        // Sort by last modified time (newest first)
        java.util.Arrays.sort(backupFiles, 
            (a, b) -> Long.compare(b.lastModified(), a.lastModified()));

        return backupFiles;
    }

    /**
     * Clean up old backup files
     */
    private void cleanupOldBackups() throws IOException {
        File[] backups = getAvailableBackups();
        
        if (backups.length > maxBackupFiles) {
            // Delete oldest backups beyond the limit
            for (int i = maxBackupFiles; i < backups.length; i++) {
                if (backups[i].delete()) {
                    logger.info("Deleted old backup file: {}", backups[i].getName());
                } else {
                    logger.warn("Failed to delete old backup file: {}", backups[i].getName());
                }
            }
        }
    }

    /**
     * Extract database name from JDBC URL
     */
    private String extractDatabaseName(String url) {
        if (url.contains("mysql")) {
            // Extract from mysql://host:port/database
            int lastSlash = url.lastIndexOf('/');
            int questionMark = url.indexOf('?', lastSlash);
            if (questionMark > 0) {
                return url.substring(lastSlash + 1, questionMark);
            } else {
                return url.substring(lastSlash + 1);
            }
        }
        return "unknown";
    }

    /**
     * Get backup status
     */
    public BackupStatus getBackupStatus() throws IOException {
        BackupStatus status = new BackupStatus();
        status.setEnabled(backupEnabled);
        status.setBackupDirectory(backupDirectory);
        status.setMaxBackupFiles(maxBackupFiles);
        
        File[] backups = getAvailableBackups();
        status.setAvailableBackups(backups.length);
        
        if (backups.length > 0) {
            status.setLastBackupTime(new java.util.Date(backups[0].lastModified()));
            status.setLastBackupSize(backups[0].length());
        }
        
        return status;
    }

    /**
     * Backup status class
     */
    public static class BackupStatus {
        private boolean enabled;
        private String backupDirectory;
        private int maxBackupFiles;
        private int availableBackups;
        private java.util.Date lastBackupTime;
        private long lastBackupSize;

        // Getters and setters
        public boolean isEnabled() {
            return enabled;
        }

        public void setEnabled(boolean enabled) {
            this.enabled = enabled;
        }

        public String getBackupDirectory() {
            return backupDirectory;
        }

        public void setBackupDirectory(String backupDirectory) {
            this.backupDirectory = backupDirectory;
        }

        public int getMaxBackupFiles() {
            return maxBackupFiles;
        }

        public void setMaxBackupFiles(int maxBackupFiles) {
            this.maxBackupFiles = maxBackupFiles;
        }

        public int getAvailableBackups() {
            return availableBackups;
        }

        public void setAvailableBackups(int availableBackups) {
            this.availableBackups = availableBackups;
        }

        public java.util.Date getLastBackupTime() {
            return lastBackupTime;
        }

        public void setLastBackupTime(java.util.Date lastBackupTime) {
            this.lastBackupTime = lastBackupTime;
        }

        public long getLastBackupSize() {
            return lastBackupSize;
        }

        public void setLastBackupSize(long lastBackupSize) {
            this.lastBackupSize = lastBackupSize;
        }
    }
}