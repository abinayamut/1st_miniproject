package com.example.library_management.exception;

/**
 * Exception thrown when a user lacks sufficient permissions
 */
public class InsufficientPermissionException extends LibraryManagementException {
    
    public InsufficientPermissionException(String action) {
        super(String.format("Insufficient permissions to perform action: %s", action));
    }
    
    public InsufficientPermissionException(String message, Throwable cause) {
        super(message, cause);
    }
}