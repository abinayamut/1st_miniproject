# Data Model

This document describes the core JPA entities used by Smart Library and key repository methods.

## Entities

### User
Fields (selected):
- `Long id`
- `String username`
- `String password`
- `String email`
- `String fullName`
- `Role role` (enum: `ADMIN`, `LIBRARIAN`, `STUDENT`)

Repository: `UserRepository`
- `Optional<User> findByUsername(String username)`
- `List<User> getUsersByRole(User.Role role)`

### Book
Fields (selected):
- `Long id`
- `String title`
- `String author`
- `String isbn`
- `String genre`
- `Integer totalCopies`
- `Integer availableCopies`

Repository: `BookRepository`
- `Optional<Book> findByIsbn(String isbn)`
- `long getTotalBookCount()`
- `long getAvailableCopiesCount()`

### Transaction
Fields (selected):
- `Long id`
- `User user` (ManyToOne)
- `Book book` (ManyToOne)
- `TransactionType type` (enum: `BORROW`, `RETURN`, `RESERVE`, `RENEW`)
- `LocalDateTime transactionDate`
- `LocalDateTime dueDate`
- `LocalDateTime returnDate`
- `Double fineAmount`
- `TransactionStatus status` (enum: `ACTIVE`, `COMPLETED`, `OVERDUE`, `CANCELLED`)

Repository: `TransactionRepository` (key methods)
- `List<Transaction> findByUser(User user)`
- `List<Transaction> findByUserAndType(User user, Transaction.TransactionType type)`
- `List<Transaction> findByUserAndTypeAndReturnDateIsNull(User user, Transaction.TransactionType type)`
- `List<Transaction> findOverdueTransactions(LocalDateTime currentDate)`
- `List<Transaction> findOverdueTransactionsByUser(User user, LocalDateTime currentDate)`
- `List<Transaction> findByUserAndFineAmountGreaterThan(User user, Double amount)`
- `List<Transaction> findByUserOrderByTransactionDateDescLimit(User user, int limit)`

### Notes
- Overdue detection is done by `Transaction.isOverdue()`, and fines are calculated per-day by `Transaction.calculateFine()`.
- `Transaction` constructor sets a default `dueDate` (14 days for BORROW) and `status` to `ACTIVE`.

