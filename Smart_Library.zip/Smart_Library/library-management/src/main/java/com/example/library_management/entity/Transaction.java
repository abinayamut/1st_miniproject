package com.example.library_management.entity;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "transactions")
public class Transaction {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "user_id", nullable = false)
    private User user;
    
    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "book_id", nullable = false)
    private Book book;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionType type;
    
    @Column(name = "transaction_date", nullable = false)
    private LocalDateTime transactionDate;
    
    @Column(name = "due_date")
    private LocalDateTime dueDate;
    
    @Column(name = "return_date")
    private LocalDateTime returnDate;
    
    @Column(name = "fine_amount")
    private Double fineAmount = 0.0;
    
    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    private TransactionStatus status;
    
    @Column(columnDefinition = "TEXT")
    private String notes;
    
    // Default constructor
    public Transaction() {}
    
    // Constructor for new transaction
    public Transaction(User user, Book book, TransactionType type) {
        this.user = user;
        this.book = book;
        this.type = type;
        this.transactionDate = LocalDateTime.now();
        this.status = TransactionStatus.ACTIVE;
        
        // Set due date for borrowed books (14 days from now)
        if (type == TransactionType.BORROW) {
            this.dueDate = LocalDateTime.now().plusDays(14);
        }
    }
    
    // Getters and Setters
    public Long getId() {
        return id;
    }
    
    public void setId(Long id) {
        this.id = id;
    }
    
    public User getUser() {
        return user;
    }
    
    public void setUser(User user) {
        this.user = user;
    }
    
    public Book getBook() {
        return book;
    }
    
    public void setBook(Book book) {
        this.book = book;
    }
    
    public TransactionType getType() {
        return type;
    }
    
    public void setType(TransactionType type) {
        this.type = type;
    }
    
    public LocalDateTime getTransactionDate() {
        return transactionDate;
    }
    
    public void setTransactionDate(LocalDateTime transactionDate) {
        this.transactionDate = transactionDate;
    }
    
    public LocalDateTime getDueDate() {
        return dueDate;
    }
    
    public void setDueDate(LocalDateTime dueDate) {
        this.dueDate = dueDate;
    }
    
    public LocalDateTime getReturnDate() {
        return returnDate;
    }
    
    public void setReturnDate(LocalDateTime returnDate) {
        this.returnDate = returnDate;
    }
    
    public Double getFineAmount() {
        return fineAmount;
    }
    
    public void setFineAmount(Double fineAmount) {
        this.fineAmount = fineAmount;
    }
    
    public TransactionStatus getStatus() {
        return status;
    }
    
    public void setStatus(TransactionStatus status) {
        this.status = status;
    }
    
    public String getNotes() {
        return notes;
    }
    
    public void setNotes(String notes) {
        this.notes = notes;
    }
    
    // Helper method to check if transaction is overdue
    public boolean isOverdue() {
        return type == TransactionType.BORROW && 
               dueDate != null && 
               LocalDateTime.now().isAfter(dueDate) && 
               returnDate == null;
    }
    
    // Calculate fine for overdue books
    public double calculateFine() {
        if (isOverdue()) {
            long daysOverdue = java.time.Duration.between(dueDate, LocalDateTime.now()).toDays();
            return daysOverdue * 1.0; // $1 per day fine
        }
        return 0.0;
    }
    
    // Enums for transaction types and status
    public enum TransactionType {
        BORROW,
        RETURN,
        RESERVE,
        RENEW
    }
    
    public enum TransactionStatus {
        ACTIVE,
        COMPLETED,
        OVERDUE,
        CANCELLED
    }
}