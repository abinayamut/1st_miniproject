package com.example.library_management.controller;

import com.example.library_management.entity.Transaction;
import com.example.library_management.entity.User;
import com.example.library_management.service.StudentStatsService;
import com.example.library_management.service.CustomUserDetailsService;
import com.example.library_management.service.BookService;
import com.example.library_management.service.RecommendationService;
import com.example.library_management.repository.UserPointsRepository;
import com.example.library_management.entity.Book;
import com.example.library_management.entity.UserPoints;
import com.example.library_management.entity.Fine;
import com.example.library_management.repository.FineRepository;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import java.util.List;

@Controller
@RequestMapping("/student")
public class StudentController {

    @Autowired
    private StudentStatsService studentStatsService;
    
    @Autowired
    private BookService bookService;

    @Autowired
    private RecommendationService recommendationService;

    @Autowired
    private UserPointsRepository userPointsRepository;

    @Autowired
    private FineRepository fineRepository;

    @GetMapping("/login")
    public String studentLogin(@RequestParam(value = "error", required = false) String error,
                             @RequestParam(value = "logout", required = false) String logout,
                             Model model) {
        
        if (error != null) {
            model.addAttribute("error", "Invalid username or password!");
        }
        
        if (logout != null) {
            model.addAttribute("message", "You have been logged out successfully!");
        }
        
        model.addAttribute("title", "Student Login - Smart Library");
        return "student-login";
    }

    @GetMapping("/dashboard")
    public String studentDashboard(Model model, Authentication authentication) {
        model.addAttribute("title", "Student Dashboard - Smart Library");
        
        // Get current user details
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal) {
            CustomUserDetailsService.CustomUserPrincipal userPrincipal = 
                (CustomUserDetailsService.CustomUserPrincipal) authentication.getPrincipal();
            User currentUser = userPrincipal.getUser();
            
            // Add user details to model
            model.addAttribute("currentUser", currentUser);
            
            // Get real-time statistics
            StudentStatsService.StudentStats stats = studentStatsService.getStudentStats(currentUser);
            model.addAttribute("borrowedBooks", stats.getBorrowedBooks());
            model.addAttribute("overdueBooks", stats.getOverdueBooks());
            model.addAttribute("reservedBooks", stats.getReservedBooks());
            model.addAttribute("totalFines", stats.getTotalFinesFormatted());
            
            // Get recent activity
            List<Transaction> recentActivity = studentStatsService.getRecentActivity(currentUser, 5);
            model.addAttribute("recentActivity", recentActivity);

            // Recommendations (PoC)
            try {
                List<Book> recs = recommendationService.getRecommendationsForUser(currentUser, 5);
                model.addAttribute("recommendations", recs);
            } catch (Exception ex) {
                System.err.println("Recommendation error: " + ex.getMessage());
            }

            // Gamification: fetch user points
            try {
                Long points = userPointsRepository.findByUser(currentUser).map(UserPoints::getPointsTotal).orElse(0L);
                model.addAttribute("userPoints", points);
            } catch (Exception ex) {
                model.addAttribute("userPoints", 0L);
            }
            
            // Add debugging info
            System.out.println("Student Dashboard - User: " + currentUser.getUsername() + 
                             ", Stats: " + stats.toString());
        }
        
        return "student-dashboard";
    }

    @GetMapping("/books")
    public String studentBooks(Model model, Authentication authentication) {
        model.addAttribute("title", "Browse Books - Student Portal");
        
        // Get current user details
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal) {
            CustomUserDetailsService.CustomUserPrincipal userPrincipal = 
                (CustomUserDetailsService.CustomUserPrincipal) authentication.getPrincipal();
            model.addAttribute("currentUser", userPrincipal.getUser());
        }
        
        // Add all available books
        model.addAttribute("books", bookService.getAllBooks());
        
        return "student-books";
    }

    @GetMapping("/borrowed")
    public String studentBorrowedBooks(Model model, Authentication authentication) {
        model.addAttribute("title", "My Borrowed Books - Student Portal");
        
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal) {
            CustomUserDetailsService.CustomUserPrincipal userPrincipal = 
                (CustomUserDetailsService.CustomUserPrincipal) authentication.getPrincipal();
            User currentUser = userPrincipal.getUser();
            model.addAttribute("currentUser", currentUser);
            
            // Get borrowed books (active transactions)
            // This would need TransactionService implementation
        }
        
        return "student-borrowed";
    }

    @GetMapping("/reservations")
    public String studentReservations(Model model, Authentication authentication) {
        model.addAttribute("title", "My Reservations - Student Portal");
        
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal) {
            CustomUserDetailsService.CustomUserPrincipal userPrincipal = 
                (CustomUserDetailsService.CustomUserPrincipal) authentication.getPrincipal();
            model.addAttribute("currentUser", userPrincipal.getUser());
        }
        
        return "student-reservations";
    }

    @GetMapping("/history")
    public String studentHistory(Model model, Authentication authentication) {
        model.addAttribute("title", "Reading History - Student Portal");
        
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal) {
            CustomUserDetailsService.CustomUserPrincipal userPrincipal = 
                (CustomUserDetailsService.CustomUserPrincipal) authentication.getPrincipal();
            User currentUser = userPrincipal.getUser();
            model.addAttribute("currentUser", currentUser);
            
            // Get transaction history
            List<Transaction> history = studentStatsService.getRecentActivity(currentUser, 20);
            model.addAttribute("transactionHistory", history);
        }
        
        return "student-history";
    }

    @GetMapping("/fines")
    public String studentFines(Model model, Authentication authentication) {
        model.addAttribute("title", "My Fines - Student Portal");
        
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal) {
            CustomUserDetailsService.CustomUserPrincipal userPrincipal = 
                (CustomUserDetailsService.CustomUserPrincipal) authentication.getPrincipal();
            User currentUser = userPrincipal.getUser();
            model.addAttribute("currentUser", currentUser);
            
            // Get statistics for fines
            StudentStatsService.StudentStats stats = studentStatsService.getStudentStats(currentUser);
            model.addAttribute("totalFines", stats.getTotalFines());
            model.addAttribute("totalFinesFormatted", stats.getTotalFinesFormatted());

            // Get unpaid fines for the user
            try {
                java.util.List<Fine> fines = fineRepository.findByUserAndPaidFalse(currentUser);
                model.addAttribute("fines", fines);
            } catch (Exception ex) {
                model.addAttribute("fines", java.util.Collections.emptyList());
            }
        }
        
        return "student-fines";
    }

    @PostMapping("/fines/pay/{id}")
    public String payFine(@PathVariable("id") Long id, Authentication authentication, RedirectAttributes redirectAttributes) {
        if (authentication == null || !(authentication.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal)) {
            return "redirect:/student/login";
        }
        CustomUserDetailsService.CustomUserPrincipal userPrincipal = (CustomUserDetailsService.CustomUserPrincipal) authentication.getPrincipal();
        User currentUser = userPrincipal.getUser();

        Fine fine = fineRepository.findById(id).orElse(null);
        if (fine == null || !fine.getUser().getId().equals(currentUser.getId())) {
            redirectAttributes.addFlashAttribute("error", "Fine not found or access denied.");
            return "redirect:/student/fines";
        }

        fine.setPaid(true);
        fineRepository.save(fine);
        redirectAttributes.addFlashAttribute("message", "Fine paid successfully.");
        return "redirect:/student/fines";
    }

    @PostMapping("/fines/dispute/{id}")
    public String disputeFine(@PathVariable("id") Long id, Authentication authentication, RedirectAttributes redirectAttributes) {
        if (authentication == null || !(authentication.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal)) {
            return "redirect:/student/login";
        }
        CustomUserDetailsService.CustomUserPrincipal userPrincipal = (CustomUserDetailsService.CustomUserPrincipal) authentication.getPrincipal();
        User currentUser = userPrincipal.getUser();

        Fine fine = fineRepository.findById(id).orElse(null);
        if (fine == null || !fine.getUser().getId().equals(currentUser.getId())) {
            redirectAttributes.addFlashAttribute("error", "Fine not found or access denied.");
            return "redirect:/student/fines";
        }

        // For PoC: mark as disputed by setting amount to same and leaving paid=false; in real app create Dispute entity
        redirectAttributes.addFlashAttribute("message", "Dispute submitted. Library staff will review.");
        return "redirect:/student/fines";
    }

    @GetMapping("/profile")
    public String studentProfile(Model model, Authentication authentication) {
        model.addAttribute("title", "My Profile - Student Portal");
        
        if (authentication != null && authentication.getPrincipal() instanceof CustomUserDetailsService.CustomUserPrincipal) {
            CustomUserDetailsService.CustomUserPrincipal userPrincipal = 
                (CustomUserDetailsService.CustomUserPrincipal) authentication.getPrincipal();
            model.addAttribute("currentUser", userPrincipal.getUser());
        }
        
        return "student-profile";
    }
}
