package com.example.library_management.service;

import com.example.library_management.entity.Transaction;
import com.example.library_management.entity.User;
import com.example.library_management.repository.TransactionRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;
import java.util.List;

@Service
public class StudentStatsService {

    @Autowired
    private TransactionRepository transactionRepository;

    /**
     * Get comprehensive statistics for a student
     */
    public StudentStats getStudentStats(User student) {
        StudentStats stats = new StudentStats();

        // Get all active borrowed books (not returned)
        List<Transaction> borrowedTransactions = transactionRepository
                .findByUserAndTypeAndReturnDateIsNull(student, Transaction.TransactionType.BORROW);
        stats.setBorrowedBooks(borrowedTransactions.size());

        // Get overdue books
        List<Transaction> overdueTransactions = transactionRepository
                .findOverdueTransactionsByUser(student, LocalDateTime.now());
        stats.setOverdueBooks(overdueTransactions.size());

        // Get reserved books
        List<Transaction> reservedTransactions = transactionRepository
                .findByUserAndType(student, Transaction.TransactionType.RESERVE);
        stats.setReservedBooks(reservedTransactions.size());

        // Calculate total fines
        double totalFines = 0.0;
        for (Transaction transaction : borrowedTransactions) {
            if (transaction.isOverdue()) {
                totalFines += transaction.calculateFine();
            }
        }
        
        // Add existing fines from returned books
        List<Transaction> fineTransactions = transactionRepository
                .findByUserAndFineAmountGreaterThan(student, 0.0);
        for (Transaction transaction : fineTransactions) {
            totalFines += transaction.getFineAmount();
        }
        
        stats.setTotalFines(totalFines);

        return stats;
    }

    /**
     * Get recent activity for a student (last 10 transactions)
     */
    public List<Transaction> getRecentActivity(User student, int limit) {
        return transactionRepository.findByUserOrderByTransactionDateDescLimit(student, limit);
    }

    /**
     * Student statistics data class
     */
    public static class StudentStats {
        private int borrowedBooks;
        private int overdueBooks;
        private int reservedBooks;
        private double totalFines;

        public StudentStats() {}

        public StudentStats(int borrowedBooks, int overdueBooks, int reservedBooks, double totalFines) {
            this.borrowedBooks = borrowedBooks;
            this.overdueBooks = overdueBooks;
            this.reservedBooks = reservedBooks;
            this.totalFines = totalFines;
        }

        // Getters and Setters
        public int getBorrowedBooks() {
            return borrowedBooks;
        }

        public void setBorrowedBooks(int borrowedBooks) {
            this.borrowedBooks = borrowedBooks;
        }

        public int getOverdueBooks() {
            return overdueBooks;
        }

        public void setOverdueBooks(int overdueBooks) {
            this.overdueBooks = overdueBooks;
        }

        public int getReservedBooks() {
            return reservedBooks;
        }

        public void setReservedBooks(int reservedBooks) {
            this.reservedBooks = reservedBooks;
        }

        public double getTotalFines() {
            return totalFines;
        }

        public void setTotalFines(double totalFines) {
            this.totalFines = totalFines;
        }

        public String getTotalFinesFormatted() {
            return String.format("$%.2f", totalFines);
        }

        @Override
        public String toString() {
            return "StudentStats{" +
                    "borrowedBooks=" + borrowedBooks +
                    ", overdueBooks=" + overdueBooks +
                    ", reservedBooks=" + reservedBooks +
                    ", totalFines=" + totalFines +
                    '}';
        }
    }
}