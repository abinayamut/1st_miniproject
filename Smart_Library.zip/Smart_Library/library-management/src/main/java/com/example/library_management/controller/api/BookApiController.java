package com.example.library_management.controller.api;

import com.example.library_management.dto.ApiResponse;
import com.example.library_management.dto.CreateBookDto;
import com.example.library_management.entity.Book;
import com.example.library_management.exception.ResourceNotFoundException;
import com.example.library_management.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageRequest;
import org.springframework.data.domain.Pageable;
import org.springframework.data.domain.Sort;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.validation.annotation.Validated;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import java.util.List;
import java.util.Optional;

/**
 * REST API controller for book management
 */
@RestController
@RequestMapping("/api/v1/books")
@Validated
public class BookApiController {

    @Autowired
    private BookService bookService;

    /**
     * Get all books with pagination
     */
    @GetMapping
    public ResponseEntity<ApiResponse<Page<Book>>> getAllBooks(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "10") int size,
            @RequestParam(defaultValue = "title") String sortBy,
            @RequestParam(defaultValue = "asc") String sortDir) {
        
        Sort sort = sortDir.equalsIgnoreCase("desc") ? 
            Sort.by(sortBy).descending() : Sort.by(sortBy).ascending();
        
        Pageable pageable = PageRequest.of(page, size, sort);
        Page<Book> books = bookService.getAllBooksPageable(pageable);
        
        return ResponseEntity.ok(ApiResponse.success(books, "Books retrieved successfully"));
    }

    /**
     * Get book by ID
     */
    @GetMapping("/{id}")
    public ResponseEntity<ApiResponse<Book>> getBookById(@PathVariable Long id) {
        Optional<Book> book = bookService.getBookById(id);
        
        if (book.isPresent()) {
            return ResponseEntity.ok(ApiResponse.success(book.get(), "Book found"));
        } else {
            throw new ResourceNotFoundException("Book", id);
        }
    }

    /**
     * Search books by title or author
     */
    @GetMapping("/search")
    public ResponseEntity<ApiResponse<List<Book>>> searchBooks(@RequestParam String query) {
        List<Book> books = bookService.searchBooks(query);
        return ResponseEntity.ok(ApiResponse.success(books, "Search completed"));
    }

    /**
     * Create a new book (Admin/Librarian only)
     */
    @PostMapping
    @PreAuthorize("hasRole('ADMIN') or hasRole('LIBRARIAN')")
    public ResponseEntity<ApiResponse<Book>> createBook(@Valid @RequestBody CreateBookDto bookDto) {
        Book book = convertToEntity(bookDto);
        Book createdBook = bookService.createBook(book);
        
        return ResponseEntity.status(HttpStatus.CREATED)
            .body(ApiResponse.success(createdBook, "Book created successfully"));
    }

    /**
     * Update an existing book (Admin/Librarian only)
     */
    @PutMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN') or hasRole('LIBRARIAN')")
    public ResponseEntity<ApiResponse<Book>> updateBook(@PathVariable Long id, 
                                                       @Valid @RequestBody CreateBookDto bookDto) {
        Book book = convertToEntity(bookDto);
        book.setId(id);
        Book updatedBook = bookService.updateBook(book);
        
        return ResponseEntity.ok(ApiResponse.success(updatedBook, "Book updated successfully"));
    }

    /**
     * Delete a book (Admin only)
     */
    @DeleteMapping("/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    public ResponseEntity<ApiResponse<Void>> deleteBook(@PathVariable Long id) {
        bookService.deleteBook(id);
        return ResponseEntity.ok(ApiResponse.success(null, "Book deleted successfully"));
    }

    /**
     * Get available books
     */
    @GetMapping("/available")
    public ResponseEntity<ApiResponse<List<Book>>> getAvailableBooks() {
        List<Book> availableBooks = bookService.getAvailableBooks();
        return ResponseEntity.ok(ApiResponse.success(availableBooks, "Available books retrieved"));
    }

    /**
     * Get books by genre
     */
    @GetMapping("/genre/{genre}")
    public ResponseEntity<ApiResponse<List<Book>>> getBooksByGenre(@PathVariable String genre) {
        List<Book> books = bookService.getBooksByGenre(genre);
        return ResponseEntity.ok(ApiResponse.success(books, "Books by genre retrieved"));
    }

    /**
     * Convert DTO to Entity
     */
    private Book convertToEntity(CreateBookDto dto) {
        Book book = new Book();
        book.setTitle(dto.getTitle());
        book.setAuthor(dto.getAuthor());
        book.setIsbn(dto.getIsbn());
        book.setPublicationYear(dto.getPublicationYear());
        book.setGenre(dto.getGenre());
        book.setTotalCopies(dto.getTotalCopies());
        book.setAvailableCopies(dto.getTotalCopies()); // Initially all copies are available
        book.setDescription(dto.getDescription());
        book.setPublisher(dto.getPublisher());
        book.setPages(dto.getPages());
        return book;
    }
}