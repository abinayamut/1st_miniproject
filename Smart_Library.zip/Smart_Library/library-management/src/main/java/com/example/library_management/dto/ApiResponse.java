package com.example.library_management.dto;

/**
 * DTO for API responses
 */
public class ApiResponse<T> {
    
    private boolean success;
    private String message;
    private T data;
    private long timestamp;
    
    // Default constructor
    public ApiResponse() {
        this.timestamp = System.currentTimeMillis();
    }
    
    // Success response constructor
    public ApiResponse(T data, String message) {
        this();
        this.success = true;
        this.data = data;
        this.message = message;
    }
    
    // Error response constructor
    public ApiResponse(String errorMessage) {
        this();
        this.success = false;
        this.message = errorMessage;
        this.data = null;
    }
    
    // Static factory methods
    public static <T> ApiResponse<T> success(T data, String message) {
        return new ApiResponse<>(data, message);
    }
    
    public static <T> ApiResponse<T> success(T data) {
        return new ApiResponse<>(data, "Operation completed successfully");
    }
    
    public static <T> ApiResponse<T> error(String message) {
        return new ApiResponse<>(message);
    }
    
    // Getters and setters
    public boolean isSuccess() {
        return success;
    }
    
    public void setSuccess(boolean success) {
        this.success = success;
    }
    
    public String getMessage() {
        return message;
    }
    
    public void setMessage(String message) {
        this.message = message;
    }
    
    public T getData() {
        return data;
    }
    
    public void setData(T data) {
        this.data = data;
    }
    
    public long getTimestamp() {
        return timestamp;
    }
    
    public void setTimestamp(long timestamp) {
        this.timestamp = timestamp;
    }
}