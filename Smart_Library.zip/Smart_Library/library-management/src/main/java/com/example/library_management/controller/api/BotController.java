package com.example.library_management.controller.api;

import com.example.library_management.dto.BotRequest;
import com.example.library_management.dto.BotResponse;
import com.example.library_management.service.BotService;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import java.security.Principal;

@RestController
@RequestMapping("/api/bot")
public class BotController {

    private final BotService botService;

    public BotController(BotService botService) {
        this.botService = botService;
    }

    @PostMapping("/message")
    public ResponseEntity<BotResponse> message(@RequestBody BotRequest request, Principal principal) {
        BotResponse resp = botService.handleMessage(request.getMessage(), principal);
        return ResponseEntity.ok(resp);
    }
}
