# Smart Library

Smart Library is a multi-role library management web application built with Spring Boot 3.5.6 and Java 21. It provides role-based access for ADMIN, LIBRARIAN and STUDENT users and includes book catalog, borrowing/reservation workflow, fines calculation, and dashboards for each role.

This repository contains the server-rendered Thymeleaf frontend and a Spring Data JPA backend (MySQL by default). The app includes a data initializer that seeds sample users, books, and transactions on startup for quick local testing.

## Quick Links
- Project: `library-management`
- Main template folder: `src/main/resources/templates`
- Static assets: `src/main/resources/static`
- Java sources: `src/main/java/com/example/library_management`

## Default credentials (created by DataInitializer)
- Admin: `admin` / `admin123`
- Librarian: `librarian` / `librarian123`
- Student: `student` / `student123`

## Quickstart (Windows)
Open Command Prompt (recommended) in project root `library-management` and run:

```powershell
# Build
mvnw.cmd clean package

# Run
mvnw.cmd spring-boot:run
```

If PowerShell is preferred, you can run the provided PowerShell script in the repo (`run-app.ps1`), but when using the Maven wrapper in PowerShell, Windows paths containing spaces can cause issues. If you hit `Files\Eclipse was unexpected at this time` errors, use Command Prompt or the bundled batch files (`run-project.bat`, `start-library.bat`).

The app listens on port `8080` by default. Visit http://localhost:8080 and login.

## Profiles
- `application.properties` configures MySQL by default (jdbc:mysql://localhost:3306/studentdb_1)
- `application-h2.properties` is available for running with H2 in-memory DB during development.

## What I added (docs)
See the `docs/` folder for architecture, setup, API, data model and contributing guidelines.

## How to contribute
See `docs/CONTRIBUTING.md` for local development, tests, and PR guidelines.
