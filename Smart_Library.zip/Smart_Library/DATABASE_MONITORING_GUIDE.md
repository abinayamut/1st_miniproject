# Database Monitoring Guide for Book Deletions

## Method 1: MySQL Command Line Monitoring

### Connect to your MySQL database:
```sql
mysql -u root -p
use studentdb_1;
```

### View all books before deletion:
```sql
SELECT * FROM books ORDER BY id;
```

### Monitor books in real-time (run this in a separate terminal):
```sql
-- Show all books with their status
SELECT 
    id, 
    title, 
    author, 
    isbn, 
    total_copies, 
    available_copies,
    created_at,
    updated_at 
FROM books 
ORDER BY id;
```

### After deletion, check what changed:
```sql
-- Count total books
SELECT COUNT(*) as total_books FROM books;

-- Check if specific book exists
SELECT * FROM books WHERE id = [BOOK_ID];

-- View recent changes (if you have logging)
SELECT * FROM books ORDER BY updated_at DESC LIMIT 10;
```

## Method 2: Using MySQL Workbench
1. Open MySQL Workbench
2. Connect to localhost:3306 with root/Abinaya@2006
3. Navigate to studentdb_1 database
4. Right-click on 'books' table → "Select Rows - Limit 1000"
5. Refresh the view after deletion to see changes

## Method 3: Application-Level Logging
✅ Enhanced BookService.java with comprehensive logging
✅ Added LibrarianController delete endpoint with logging
✅ Updated frontend to call real API endpoints

## Method 4: Database Monitor Dashboard
Access: http://localhost:8080/librarian/database-monitor
Features:
- Real-time database statistics
- Live activity log
- Current books table view
- Auto-refresh capability (5-second intervals)

## Method 5: Spring Boot Console Logs
When you run the application, watch the console for these log messages:

### Before Deletion:
```
=== BOOK DELETION LOG ===
Deleting Book ID: 5
Title: Clean Code
Author: Robert C. Martin
ISBN: 978-0-13-235088-4
Total Copies: 4
Available Copies: 3
Deletion Time: 2025-09-26T10:30:45.123
========================
```

### After Deletion:
```
Book successfully deleted from database!
Remaining books count: 10
Librarian 'admin' is deleting book with ID: 5
```

## Method 6: Browser Developer Console
1. Open librarian books page: http://localhost:8080/librarian/books
2. Open Developer Tools (F12)
3. Go to Console tab
4. Delete a book
5. Watch for these messages:

### Successful Deletion:
```javascript
Confirming deletion of book with ID: 5
Delete response from server: Book deleted successfully
Book "Clean Code" (ID: 5) successfully deleted from database
```

### Error Messages:
```javascript
Error deleting book from database: [error details]
```

## Testing Steps:

### 1. Start the Application:
```powershell
cd "library-management"
.\mvnw.cmd spring-boot:run
```

### 2. Open Multiple Monitoring Views:
- MySQL Command Line: `mysql -u root -p`
- Application Console: Watch Spring Boot logs
- Database Monitor: http://localhost:8080/librarian/database-monitor
- Librarian Portal: http://localhost:8080/librarian/books
- Browser Console: Developer Tools → Console

### 3. Test Book Deletion:
1. Login as librarian (admin/admin123)
2. Go to Books Management
3. Click Delete on any book
4. Confirm deletion
5. Observe all monitoring points simultaneously

### 4. Verification Checklist:
- [ ] MySQL shows book is removed from table
- [ ] Application console shows deletion logs
- [ ] Database monitor updates statistics
- [ ] Frontend removes book card
- [ ] Browser console shows success messages
- [ ] Book count decreases by 1

## Database Schema Reference:
```sql
CREATE TABLE books (
    id BIGINT AUTO_INCREMENT PRIMARY KEY,
    title VARCHAR(255) NOT NULL,
    author VARCHAR(255) NOT NULL,
    isbn VARCHAR(255) UNIQUE,
    publication_year INT,
    genre VARCHAR(255) NOT NULL,
    total_copies INT,
    available_copies INT,
    description TEXT,
    created_at DATETIME,
    updated_at DATETIME
);
```

## API Endpoints:
- DELETE `/librarian/books/{id}` - Delete book by ID
- GET `/librarian/books/all` - Get all books (JSON)
- GET `/librarian/database-monitor` - Database monitoring dashboard

## Troubleshooting:

### If deletion fails:
1. Check console logs for error messages
2. Verify database connection in application.properties
3. Ensure book ID exists in database
4. Check user permissions

### If monitoring doesn't work:
1. Refresh the database monitor page
2. Enable auto-refresh feature
3. Check browser console for JavaScript errors
4. Verify API endpoints are accessible