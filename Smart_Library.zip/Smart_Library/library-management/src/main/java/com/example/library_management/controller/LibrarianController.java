package com.example.library_management.controller;

import com.example.library_management.entity.LibrarianSettings;
import com.example.library_management.entity.User;
import com.example.library_management.entity.Book;
import com.example.library_management.service.LibrarianSettingsService;
import com.example.library_management.service.UserService;
import com.example.library_management.service.BookService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import java.util.Optional;

@Controller
@RequestMapping("/librarian")
public class LibrarianController {
    
    @Autowired
    private LibrarianSettingsService librarianSettingsService;
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private BookService bookService;

    @GetMapping("/login")
    public String librarianLogin(@RequestParam(value = "error", required = false) String error,
                               @RequestParam(value = "logout", required = false) String logout,
                               Model model) {
        
        if (error != null) {
            model.addAttribute("error", "Invalid librarian ID or password!");
        }
        
        if (logout != null) {
            model.addAttribute("message", "You have been logged out successfully!");
        }
        
        model.addAttribute("title", "Librarian Login - Smart Library");
        return "librarian-login";
    }

    @PostMapping("/login")
    public String handleLibrarianLogin(@RequestParam("librarianId") String librarianId,
                                     @RequestParam("password") String password,
                                     Model model) {
        
        // Simple authentication check for demo librarians
        if (("LIB001".equals(librarianId) && "lib123".equals(password)) ||
            ("LIB002".equals(librarianId) && "library456".equals(password))) {
            
            model.addAttribute("librarianId", librarianId);
            model.addAttribute("librarianName", getLibrarianName(librarianId));
            return "redirect:/librarian/dashboard?id=" + librarianId;
        } else {
            model.addAttribute("error", "Invalid librarian ID or password!");
            model.addAttribute("title", "Librarian Login - Smart Library");
            return "librarian-login";
        }
    }

    @GetMapping("/dashboard")
    public String librarianDashboard(@RequestParam(value = "id", required = false) String librarianId,
                                   Model model) {
        
        if (librarianId == null) librarianId = "LIB001"; // Default for direct access
        
        model.addAttribute("title", "Librarian Dashboard - Smart Library");
        model.addAttribute("librarianId", librarianId);
        model.addAttribute("librarianName", getLibrarianName(librarianId));
        return "librarian-dashboard";
    }

    @GetMapping("/books")
    public String librarianBooks(Model model) {
        model.addAttribute("title", "Book Management - Librarian Portal");
        return "librarian-books";
    }

    @GetMapping("/students")
    public String librarianStudents(Model model) {
        model.addAttribute("title", "Student Management - Librarian Portal");
        return "librarian-students";
    }

    @GetMapping("/transactions")
    public String librarianTransactions(Model model) {
        model.addAttribute("title", "Transactions - Librarian Portal");
        return "librarian-transactions";
    }

    @PostMapping("/logout")
    public String librarianLogout() {
        return "redirect:/librarian/login?logout=true";
    }

    @GetMapping("/settings")
    public String librarianSettings(Model model, Authentication authentication) {
        model.addAttribute("title", "Librarian Settings - Smart Library");
        
        // Get current user from authentication
        String username = authentication.getName();
        Optional<User> userOptional = userService.findByUsername(username);
        
        if (userOptional.isPresent()) {
            User currentUser = userOptional.get();
            
            // Get settings for the user (service will create if not exists)
            LibrarianSettings settings = librarianSettingsService.getSettingsByUserId(currentUser.getId());
            
            // Add user info to model
            model.addAttribute("currentUser", currentUser);
            model.addAttribute("settings", settings);
            
            // Add form data attributes for backwards compatibility
            model.addAttribute("librarianName", currentUser.getFullName());
            model.addAttribute("librarianId", currentUser.getUsername());
            model.addAttribute("email", settings.getEmail());
            model.addAttribute("department", settings.getDepartment());
            model.addAttribute("joinDate", currentUser.getCreatedAt().toString());
            
            // Notification preferences
            model.addAttribute("emailNotifications", settings.getEmailNotifications());
            model.addAttribute("smsNotifications", settings.getSmsNotifications());
            model.addAttribute("overdueAlerts", settings.getOverdueAlerts());
            model.addAttribute("systemTheme", settings.getSystemTheme());
            model.addAttribute("language", settings.getLanguage());
            model.addAttribute("workingHours", settings.getWorkingHours());
        }
        
        return "librarian-settings";
    }

    @PostMapping("/settings/update")
    public String updateLibrarianSettings(@ModelAttribute LibrarianSettings settingsForm,
                                        Authentication authentication,
                                        RedirectAttributes redirectAttributes) {
        
        try {
            // Get current user from authentication
            String username = authentication.getName();
            Optional<User> userOptional = userService.findByUsername(username);
            
            if (userOptional.isPresent()) {
                User currentUser = userOptional.get();
                
                // Update settings using the service
                librarianSettingsService.updateSettings(currentUser.getId(), settingsForm);
                redirectAttributes.addFlashAttribute("successMessage", "Settings updated successfully!");
            } else {
                redirectAttributes.addFlashAttribute("errorMessage", "User not found!");
            }
        } catch (Exception e) {
            redirectAttributes.addFlashAttribute("errorMessage", "Error updating settings: " + e.getMessage());
        }
        
        return "redirect:/librarian/settings";
    }

    // Book CRUD operations
    @DeleteMapping("/books/{id}")
    @ResponseBody
    public String deleteBook(@PathVariable Long id, Authentication authentication) {
        try {
            // Log who is deleting the book
            String librarianUsername = authentication.getName();
            System.out.println("Librarian '" + librarianUsername + "' is deleting book with ID: " + id);
            
            // Delete the book (this will trigger our enhanced logging)
            bookService.deleteBook(id);
            
            return "Book deleted successfully";
        } catch (Exception e) {
            System.err.println("Error deleting book with ID " + id + ": " + e.getMessage());
            return "Error deleting book: " + e.getMessage();
        }
    }
    
    @GetMapping("/books/all")
    @ResponseBody
    public java.util.List<Book> getAllBooks() {
        return bookService.getAllBooks();
    }
    
    @GetMapping("/database-monitor")
    public String databaseMonitor(Model model) {
        model.addAttribute("title", "Database Monitor - Librarian Portal");
        return "database-monitor";
    }

    private String getLibrarianName(String librarianId) {
        switch (librarianId) {
            case "LIB001": return "Sarah Wilson";
            case "LIB002": return "Michael Brown";
            default: return "Librarian";
        }
    }
}
