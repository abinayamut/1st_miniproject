package com.example.library_management.controller;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestParam;

/**
 * Controller for handling authentication-related pages
 */
@Controller
public class AuthController {

    private static final Logger logger = LoggerFactory.getLogger(AuthController.class);

    /**
     * Display the common login page for all user types
     */
    @GetMapping("/login")
    public String loginPage(@RequestParam(value = "error", required = false) String error,
                           @RequestParam(value = "logout", required = false) String logout,
                           @RequestParam(value = "message", required = false) String message,
                           Model model) {

        // Check if user is already authenticated and redirect to appropriate dashboard
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        if (auth != null && auth.isAuthenticated() && !auth.getName().equals("anonymousUser")) {
            logger.info("User '{}' is already authenticated, redirecting to dashboard", auth.getName());
            return "redirect:" + getDashboardUrl(auth);
        }

        model.addAttribute("title", "Login - Smart Library Management System");

        // Handle error messages
        if (error != null) {
            if (message != null && !message.isEmpty()) {
                model.addAttribute("errorMessage", message);
            } else {
                model.addAttribute("errorMessage", "Invalid username or password. Please try again.");
            }
            logger.warn("Login error displayed: {}", message != null ? message : "Invalid credentials");
        }

        // Handle logout message
        if (logout != null) {
            model.addAttribute("logoutMessage", "You have been successfully logged out.");
            logger.info("User logged out successfully");
        }

        return "login-new";
    }

    /**
     * Access denied page
     */
    @GetMapping("/403")
    public String accessDenied(Model model, Authentication authentication) {
        model.addAttribute("title", "Access Denied - Smart Library");
        
        if (authentication != null) {
            String username = authentication.getName();
            String role = authentication.getAuthorities().iterator().next().getAuthority();
            model.addAttribute("username", username);
            model.addAttribute("userRole", role.replace("ROLE_", ""));
            logger.warn("Access denied for user '{}' with role '{}'", username, role);
        }
        
        return "403";
    }

    /**
     * Determine dashboard URL based on user role
     */
    private String getDashboardUrl(Authentication auth) {
        return auth.getAuthorities().stream()
                .map(authority -> {
                    String role = authority.getAuthority();
                    switch (role) {
                        case "ROLE_ADMIN":
                            return "/admin/dashboard";
                        case "ROLE_LIBRARIAN":
                            return "/librarian/dashboard";
                        case "ROLE_STUDENT":
                            return "/student/dashboard";
                        default:
                            return "/";
                    }
                })
                .findFirst()
                .orElse("/");
    }

    /**
     * Default page after login for role detection
     */
    @GetMapping("/dashboard")
    public String dashboard(Authentication authentication) {
        if (authentication == null || !authentication.isAuthenticated()) {
            return "redirect:/login";
        }

        String redirectUrl = getDashboardUrl(authentication);
        logger.info("Redirecting authenticated user '{}' to '{}'", authentication.getName(), redirectUrl);
        return "redirect:" + redirectUrl;
    }
}