# Smart Library — Architecture Overview

This document describes the high-level architecture of Smart Library and where to find each major component in the codebase.

## Technology Stack
- Java 21
- Spring Boot 3.5.6
- Spring Data JPA (Hibernate) for persistence
- Thymeleaf for server-rendered views
- MySQL (primary) / H2 (development profile)
- Maven (wrapper included)

## Project Structure
- `src/main/java/com/example/library_management`
  - `controller/` — MVC controllers for `admin`, `librarian`, `student`, plus `AuthController` and `HomeController`.
  - `service/` — Business logic, e.g., `BookService`, `UserService`, `StudentStatsService`, `TransactionService`.
  - `repository/` — Spring Data JPA repositories: `BookRepository`, `TransactionRepository`, `UserRepository`.
  - `entity/` — JPA entities: `User`, `Book`, `Transaction`, `LibrarianSettings`.
  - `config/` — Security (`SecurityConfig`), data seeding (`DataInitializer`), and auth handlers.

- `src/main/resources`
  - `templates/` — Thymeleaf templates (role-based naming: `admin-*.html`, `librarian-*.html`, `student-*.html`).
  - `static/` — CSS and other static assets.
  - `application.properties` — MySQL configuration and production defaults.
  - `application-h2.properties` — H2 in-memory configuration for local dev/testing.

## Security & Authentication
- Spring Security is used with role-based access.
  - Routes mapping examples:
    - `/admin/**` → ROLE_ADMIN
    - `/librarian/**` → ROLE_LIBRARIAN
    - `/student/**` → ROLE_STUDENT
- There is a `CustomUserDetailsService` and a `SecurityConfig` that defines form-login, success/failure handlers, and an access-denied page (`/403`).

## Data Initialization
- `DataInitializer` seeds default users (admin/librarian/student) and sample books on startup. It can be extended to seed transactions as needed.

## Services & Patterns
- Services implement business logic and talk to repositories. They return "Stats" DTOs where useful (e.g., `UserService.getUserStats()` and `BookService.getBookStats()`).
- Repositories provide both derived query methods and `@Query`-annotated custom JPQL queries used across the app.

## Templates & UI Patterns
- Templates use Thymeleaf with role fragments. Shared navbar fragments and role-specific menus are located in `templates/fragments`.
- Template names are role-prefixed: `admin-dashboard.html`, `librarian-dashboard.html`, `student-dashboard.html`.

## Notes and Extensibility
- To add a new role: add repository/service/controller and update `SecurityConfig` role mapping and templates.
- To add API endpoints (REST) consider adding `@RestController` classes under `controller/api` and versioning (`/api/v1`).

