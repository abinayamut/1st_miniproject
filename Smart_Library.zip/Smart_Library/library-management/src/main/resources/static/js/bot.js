document.addEventListener('DOMContentLoaded', function() {
  const chat = document.getElementById('chat');
  const form = document.getElementById('chat-form');
  const input = document.getElementById('message-input');
  const sendBtn = document.getElementById('send-btn');

  function appendMessage(from, text) {
    const p = document.createElement('div');
    p.className = 'message ' + (from === 'user' ? 'user' : 'bot');
    p.innerText = text;
    chat.appendChild(p);
    chat.scrollTop = chat.scrollHeight;
  }

  async function sendMessage(text) {
    appendMessage('user', text);
    // Read csrf token
    const token = document.querySelector('meta[name="_csrf"]').getAttribute('content');
    const header = document.querySelector('meta[name="_csrf_header"]').getAttribute('content');

    try {
      const res = await fetch('/api/bot/message', {
        method: 'POST',
        headers: Object.assign({ 'Content-Type': 'application/json' }, { [header]: token }),
        body: JSON.stringify({ message: text })
      });
      if (!res.ok) throw new Error('Network response not ok');
      const data = await res.json();
      appendMessage('bot', data.reply || data.reply || 'No reply');
    } catch (e) {
      appendMessage('bot', 'Error: ' + e.message);
    }
  }

  sendBtn.addEventListener('click', function() {
    const v = input.value.trim();
    if (!v) return;
    sendMessage(v);
    input.value = '';
  });

  input.addEventListener('keydown', function(e) {
    if (e.key === 'Enter') {
      e.preventDefault();
      sendBtn.click();
    }
  });
});
