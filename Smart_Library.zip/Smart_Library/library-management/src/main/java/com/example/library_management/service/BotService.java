package com.example.library_management.service;

import com.example.library_management.dto.BotResponse;
import com.example.library_management.entity.Book;
import com.example.library_management.entity.User;
import com.example.library_management.repository.UserRepository;
import org.springframework.stereotype.Service;

import java.security.Principal;
import java.util.List;
import java.util.Optional;
import java.util.stream.Collectors;

@Service
public class BotService {

    private final BookService bookService;
    private final TransactionService transactionService;
    private final UserRepository userRepository;

    public BotService(BookService bookService, TransactionService transactionService, UserRepository userRepository) {
        this.bookService = bookService;
        this.transactionService = transactionService;
        this.userRepository = userRepository;
    }

    /**
     * Handle a user message and return a reply. Simple rule-based bot that integrates with BookService/TransactionService.
     */
    public BotResponse handleMessage(String message, Principal principal) {
        if (message == null) return new BotResponse("Sorry, I didn't get that. Try 'help' or 'search <title>'.");

        String m = message.trim().toLowerCase();

        if (m.equals("help") || m.equals("hi") || m.equals("hello")) {
            return new BotResponse("Hi — I can help you search books (type: search <keyword>), check your borrowed books (type: my borrowed), or say 'help' to see this message.");
        }

        if (m.startsWith("search ") || m.startsWith("search:")) {
            String keyword = message.replaceFirst("(?i)search[: ]", "").trim();
            if (keyword.isEmpty()) return new BotResponse("Please provide a search keyword, e.g. 'search clean code'.");
            List<Book> results = bookService.searchBooks(keyword);
            if (results.isEmpty()) return new BotResponse("No books found for '" + keyword + "'.");
            String reply = results.stream().limit(5).map(b -> b.getTitle() + " by " + b.getAuthor()).collect(Collectors.joining("\n"));
            return new BotResponse("Found books:\n" + reply);
        }

        if (m.equals("my borrowed") || m.equals("borrowed")) {
            if (principal == null) return new BotResponse("Please log in to check your borrowed books.");
            Optional<User> u = userRepository.findByUsername(principal.getName());
            if (!u.isPresent()) return new BotResponse("Unable to locate your account. Try logging in again.");
            List<com.example.library_management.entity.Transaction> active = transactionService.getActiveBorrowedBooks(u.get());
            if (active.isEmpty()) return new BotResponse("You have no active borrowed books.");
            String reply = active.stream().map(t -> t.getBook().getTitle() + " (due: " + (t.getDueDate() != null ? t.getDueDate().toLocalDate().toString() : "N/A") + ")").collect(Collectors.joining("\n"));
            return new BotResponse("Your active borrows:\n" + reply);
        }

        // default fallback
        return new BotResponse("Sorry, I didn't understand. Type 'help' to see what I can do.");
    }
}
