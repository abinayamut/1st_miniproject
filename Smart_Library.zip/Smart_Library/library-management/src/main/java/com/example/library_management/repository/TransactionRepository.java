package com.example.library_management.repository;

import com.example.library_management.entity.Transaction;
import com.example.library_management.entity.Role;
import com.example.library_management.entity.User;
import com.example.library_management.entity.Book;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;
import java.time.LocalDateTime;
import java.util.List;

@Repository
public interface TransactionRepository extends JpaRepository<Transaction, Long> {
    
    List<Transaction> findByUser(User user);
    
    List<Transaction> findByBook(Book book);
    
    List<Transaction> findByType(Transaction.TransactionType type);
    
    List<Transaction> findByStatus(Transaction.TransactionStatus status);
    
    List<Transaction> findByUserAndStatus(User user, Transaction.TransactionStatus status);
    
    List<Transaction> findByUserAndType(User user, Transaction.TransactionType type);
    
    @Query("SELECT t FROM Transaction t WHERE t.dueDate < :currentDate AND t.returnDate IS NULL AND t.type = 'BORROW'")
    List<Transaction> findOverdueTransactions(@Param("currentDate") LocalDateTime currentDate);
    
    @Query("SELECT t FROM Transaction t WHERE t.user = :user AND t.book = :book AND t.type = 'BORROW' AND t.returnDate IS NULL")
    List<Transaction> findActiveBorrowTransactions(@Param("user") User user, @Param("book") Book book);
    
    @Query("SELECT t FROM Transaction t WHERE t.transactionDate BETWEEN :startDate AND :endDate")
    List<Transaction> findTransactionsBetweenDates(@Param("startDate") LocalDateTime startDate, @Param("endDate") LocalDateTime endDate);
    
    @Query("SELECT COUNT(t) FROM Transaction t WHERE t.type = 'BORROW'")
    long getTotalBorrowCount();
    
    @Query("SELECT COUNT(t) FROM Transaction t WHERE t.type = 'RETURN'")
    long getTotalReturnCount();
    
    @Query("SELECT COUNT(t) FROM Transaction t WHERE t.status = 'OVERDUE'")
    long getOverdueCount();
    
    @Query("SELECT b.genre, COUNT(t) FROM Transaction t JOIN t.book b WHERE t.type = 'BORROW' GROUP BY b.genre ORDER BY COUNT(t) DESC")
    List<Object[]> getPopularGenres();
    
    @Query("SELECT b, COUNT(t) FROM Transaction t JOIN t.book b WHERE t.type = 'BORROW' GROUP BY b ORDER BY COUNT(t) DESC")
    List<Object[]> getPopularBooks();
    
    @Query("SELECT t FROM Transaction t WHERE t.user.role = :role ORDER BY t.transactionDate DESC")
    List<Transaction> findTransactionsByUserRole(@Param("role") Role role);
    
    // Student-specific queries
    @Query("SELECT t FROM Transaction t WHERE t.user = :user AND t.type = :type AND t.returnDate IS NULL")
    List<Transaction> findByUserAndTypeAndReturnDateIsNull(@Param("user") User user, @Param("type") Transaction.TransactionType type);

    @Query("SELECT t FROM Transaction t WHERE t.user = :user AND t.dueDate < :currentDate AND t.returnDate IS NULL AND t.type = 'BORROW'")
    List<Transaction> findOverdueTransactionsByUser(@Param("user") User user, @Param("currentDate") LocalDateTime currentDate);

    @Query("SELECT t FROM Transaction t WHERE t.user = :user AND t.fineAmount > :amount")
    List<Transaction> findByUserAndFineAmountGreaterThan(@Param("user") User user, @Param("amount") Double amount);

    @Query("SELECT t FROM Transaction t WHERE t.user = :user ORDER BY t.transactionDate DESC LIMIT :limit")
    List<Transaction> findByUserOrderByTransactionDateDescLimit(@Param("user") User user, @Param("limit") int limit);
}