package com.example.library_management.exception;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.validation.BindException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import jakarta.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.Map;

/**
 * Global exception handler for the Smart Library application
 */
@ControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);
    
    // Constants for view attributes
    private static final String ERROR_VIEW = "error";
    private static final String TITLE_ATTR = "title";
    private static final String ERROR_CODE_ATTR = "errorCode";
    private static final String ERROR_MESSAGE_ATTR = "errorMessage";
    private static final String REQUEST_URL_ATTR = "requestUrl";
    private static final String STATUS_ERROR = "error";

    /**
     * Handle ResourceNotFoundException
     */
    @ExceptionHandler(ResourceNotFoundException.class)
    public ModelAndView handleResourceNotFound(ResourceNotFoundException ex, HttpServletRequest request) {
        logger.error("Resource not found: {}", ex.getMessage());
        
        ModelAndView mav = new ModelAndView(ERROR_VIEW);
        mav.addObject(TITLE_ATTR, "Resource Not Found");
        mav.addObject(ERROR_CODE_ATTR, "404");
        mav.addObject(ERROR_MESSAGE_ATTR, ex.getMessage());
        mav.addObject(REQUEST_URL_ATTR, request.getRequestURL().toString());
        mav.setStatus(HttpStatus.NOT_FOUND);
        
        return mav;
    }

    /**
     * Handle BusinessRuleViolationException
     */
    @ExceptionHandler(BusinessRuleViolationException.class)
    public ModelAndView handleBusinessRuleViolation(BusinessRuleViolationException ex, HttpServletRequest request) {
        logger.warn("Business rule violation: {}", ex.getMessage());
        
        ModelAndView mav = new ModelAndView(ERROR_VIEW);
        mav.addObject(TITLE_ATTR, "Business Rule Violation");
        mav.addObject(ERROR_CODE_ATTR, "400");
        mav.addObject(ERROR_MESSAGE_ATTR, ex.getMessage());
        mav.addObject(REQUEST_URL_ATTR, request.getRequestURL().toString());
        mav.setStatus(HttpStatus.BAD_REQUEST);
        
        return mav;
    }

    /**
     * Handle InsufficientPermissionException
     */
    @ExceptionHandler(InsufficientPermissionException.class)
    public ModelAndView handleInsufficientPermission(InsufficientPermissionException ex, HttpServletRequest request) {
        logger.warn("Insufficient permission: {}", ex.getMessage());
        
        ModelAndView mav = new ModelAndView(ERROR_VIEW);
        mav.addObject(TITLE_ATTR, "Access Denied");
        mav.addObject(ERROR_CODE_ATTR, "403");
        mav.addObject(ERROR_MESSAGE_ATTR, ex.getMessage());
        mav.addObject(REQUEST_URL_ATTR, request.getRequestURL().toString());
        mav.setStatus(HttpStatus.FORBIDDEN);
        
        return mav;
    }

    /**
     * Handle validation errors from @Valid annotations
     */
    @ExceptionHandler({MethodArgumentNotValidException.class, BindException.class})
    @ResponseBody
    public ResponseEntity<Map<String, Object>> handleValidationErrors(Exception ex) {
        logger.warn("Validation error: {}", ex.getMessage());
        
        Map<String, Object> response = new HashMap<>();
        Map<String, String> errors = new HashMap<>();
        
        if (ex instanceof MethodArgumentNotValidException validEx) {
            validEx.getBindingResult().getAllErrors().forEach(error -> {
                String fieldName = ((FieldError) error).getField();
                String errorMessage = error.getDefaultMessage();
                errors.put(fieldName, errorMessage);
            });
        } else if (ex instanceof BindException bindEx) {
            bindEx.getBindingResult().getAllErrors().forEach(error -> {
                String fieldName = ((FieldError) error).getField();
                String errorMessage = error.getDefaultMessage();
                errors.put(fieldName, errorMessage);
            });
        }
        
        response.put("status", STATUS_ERROR);
        response.put("message", "Validation failed");
        response.put("errors", errors);
        
        return ResponseEntity.badRequest().body(response);
    }

    /**
     * Handle database constraint violations
     */
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ModelAndView handleDataIntegrityViolation(DataIntegrityViolationException ex, HttpServletRequest request) {
        logger.error("Data integrity violation: {}", ex.getMessage());
        
        String userMessage = "A database constraint was violated. This might be due to duplicate data or foreign key constraints.";
        if (ex.getMessage().contains("Duplicate entry")) {
            userMessage = "This record already exists in the system.";
        } else if (ex.getMessage().contains("foreign key constraint")) {
            userMessage = "Cannot delete this record because it is referenced by other data.";
        }
        
        ModelAndView mav = new ModelAndView(ERROR_VIEW);
        mav.addObject(TITLE_ATTR, "Data Constraint Violation");
        mav.addObject(ERROR_CODE_ATTR, "409");
        mav.addObject(ERROR_MESSAGE_ATTR, userMessage);
        mav.addObject(REQUEST_URL_ATTR, request.getRequestURL().toString());
        mav.setStatus(HttpStatus.CONFLICT);
        
        return mav;
    }

    /**
     * Handle Spring Security access denied
     */
    @ExceptionHandler(AccessDeniedException.class)
    public ModelAndView handleAccessDenied(AccessDeniedException ex, HttpServletRequest request) {
        logger.warn("Access denied: {}", ex.getMessage());
        
        ModelAndView mav = new ModelAndView("403");
        mav.addObject(TITLE_ATTR, "Access Denied");
        mav.addObject(ERROR_MESSAGE_ATTR, "You don't have permission to access this resource.");
        mav.addObject(REQUEST_URL_ATTR, request.getRequestURL().toString());
        
        return mav;
    }

    /**
     * Handle generic exceptions
     */
    @ExceptionHandler(Exception.class)
    public ModelAndView handleGenericException(Exception ex, HttpServletRequest request) {
        logger.error("Unexpected error occurred: ", ex);
        
        ModelAndView mav = new ModelAndView(ERROR_VIEW);
        mav.addObject(TITLE_ATTR, "Internal Server Error");
        mav.addObject(ERROR_CODE_ATTR, "500");
        mav.addObject(ERROR_MESSAGE_ATTR, "An unexpected error occurred. Please try again later.");
        mav.addObject(REQUEST_URL_ATTR, request.getRequestURL().toString());
        mav.setStatus(HttpStatus.INTERNAL_SERVER_ERROR);
        
        return mav;
    }

    /**
     * Handle API exceptions and return JSON response
     */
    @ExceptionHandler({ResourceNotFoundException.class, BusinessRuleViolationException.class})
    @ResponseBody
    public ResponseEntity<Map<String, Object>> handleApiExceptions(LibraryManagementException ex) {
        logger.error("API error: {}", ex.getMessage());
        
        Map<String, Object> response = new HashMap<>();
        response.put("status", STATUS_ERROR);
        response.put("message", ex.getMessage());
        response.put("timestamp", System.currentTimeMillis());
        
        HttpStatus status = HttpStatus.INTERNAL_SERVER_ERROR;
        if (ex instanceof ResourceNotFoundException) {
            status = HttpStatus.NOT_FOUND;
        } else if (ex instanceof BusinessRuleViolationException) {
            status = HttpStatus.BAD_REQUEST;
        } else if (ex instanceof InsufficientPermissionException) {
            status = HttpStatus.FORBIDDEN;
        }
        
        return ResponseEntity.status(status).body(response);
    }
}