Set-Location "C:\Users\HP\OneDrive\Documents\java programs\College works\mini project file\Smart_Library\library-management"
$env:JAVA_HOME = "C:\Program Files\Eclipse Adoptium\jdk-21.0.8.9-hotspot"
Write-Host "Starting Smart Library Management System..."
& cmd /c "mvnw.cmd spring-boot:run"