# PowerShell script to run Smart Library Spring Boot application
Set-Location $PSScriptRoot
$env:JAVA_HOME = "C:\Program Files\Eclipse Adoptium\jdk-21.0.8.9-hotspot"

Write-Host "Starting Smart Library Application..." -ForegroundColor Green
Write-Host "Java Home: $env:JAVA_HOME" -ForegroundColor Yellow
Write-Host "Current Directory: $(Get-Location)" -ForegroundColor Yellow

try {
    # Try to run with Maven wrapper
    & cmd /c "mvnw.cmd spring-boot:run"
}
catch {
    Write-Host "Error running the application: $_" -ForegroundColor Red
    Write-Host "Press any key to exit..." -ForegroundColor Yellow
    $null = $Host.UI.RawUI.ReadKey("NoEcho,IncludeKeyDown")
}