package com.example.library_management.repository;

import com.example.library_management.entity.LibrarianSettings;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface LibrarianSettingsRepository extends JpaRepository<LibrarianSettings, Long> {
    
    /**
     * Find settings by user ID
     */
    Optional<LibrarianSettings> findByUserId(Long userId);
    
    /**
     * Check if settings exist for a user
     */
    boolean existsByUserId(Long userId);
    
    /**
     * Delete settings by user ID
     */
    void deleteByUserId(Long userId);
    
    /**
     * Find all librarians with email notifications enabled
     */
    @Query("SELECT ls FROM LibrarianSettings ls WHERE ls.emailNotifications = true")
    java.util.List<LibrarianSettings> findAllWithEmailNotificationsEnabled();
    
    /**
     * Find all librarians with SMS notifications enabled
     */
    @Query("SELECT ls FROM LibrarianSettings ls WHERE ls.smsNotifications = true")
    java.util.List<LibrarianSettings> findAllWithSmsNotificationsEnabled();
    
    /**
     * Find all librarians with overdue alerts enabled
     */
    @Query("SELECT ls FROM LibrarianSettings ls WHERE ls.overdueAlerts = true")
    java.util.List<LibrarianSettings> findAllWithOverdueAlertsEnabled();
    
    /**
     * Find librarians by department
     */
    @Query("SELECT ls FROM LibrarianSettings ls WHERE ls.department = :department")
    java.util.List<LibrarianSettings> findByDepartment(@Param("department") String department);
    
    /**
     * Find librarians by availability status
     */
    @Query("SELECT ls FROM LibrarianSettings ls WHERE ls.availabilityStatus = :status")
    java.util.List<LibrarianSettings> findByAvailabilityStatus(@Param("status") String status);
    
    /**
     * Count librarians by theme preference
     */
    @Query("SELECT COUNT(ls) FROM LibrarianSettings ls WHERE ls.systemTheme = :theme")
    Long countBySystemTheme(@Param("theme") String theme);
    
    /**
     * Find librarians with two-factor authentication enabled
     */
    @Query("SELECT ls FROM LibrarianSettings ls WHERE ls.twoFactorAuth = true")
    java.util.List<LibrarianSettings> findAllWithTwoFactorAuthEnabled();
}