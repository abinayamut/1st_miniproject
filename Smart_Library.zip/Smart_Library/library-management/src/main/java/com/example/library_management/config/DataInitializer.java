package com.example.library_management.config;

import com.example.library_management.service.UserService;
import com.example.library_management.service.BookService;
import com.example.library_management.service.TransactionService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

@Component
public class DataInitializer implements CommandLineRunner {
    
    @Autowired
    private UserService userService;
    
    @Autowired
    private BookService bookService;
    
    @Autowired
    private TransactionService transactionService;
    
    @Override
    public void run(String... args) throws Exception {
        // Create default users on application startup
        userService.createDefaultUsers();
        System.out.println("Default users created successfully!");
        System.out.println("Admin credentials: admin / admin123");
        System.out.println("Librarian credentials: librarian / librarian123");
        System.out.println("Student credentials: student / student123");
        
        // Create sample books
        bookService.createSampleBooks();
        System.out.println("Sample books data initialized!");
        
        // Create sample transactions for real-time dashboard statistics
        transactionService.createSampleTransactions();
        System.out.println("Sample transactions data initialized!");
        
        System.out.println("=================================");
        System.out.println("🚀 Smart Library Application Ready!");
        System.out.println("📊 Real-time dashboard statistics enabled");
        System.out.println("🔐 Login with: student / student123");
        System.out.println("=================================");
    }
}