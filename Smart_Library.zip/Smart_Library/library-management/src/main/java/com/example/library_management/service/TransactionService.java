package com.example.library_management.service;

import com.example.library_management.entity.Transaction;
import com.example.library_management.entity.User;
import com.example.library_management.entity.Book;
import com.example.library_management.repository.TransactionRepository;
import com.example.library_management.repository.UserRepository;
import com.example.library_management.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class TransactionService {

    @Autowired
    private TransactionRepository transactionRepository;
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private BookRepository bookRepository;

    @Autowired
    private GamificationService gamificationService;

    /**
     * Create sample transactions for demonstration
     */
    public void createSampleTransactions() {
        if (transactionRepository.count() > 0) {
            return; // Transactions already exist
        }

        System.out.println("Creating sample transactions...");

        // Get the default student
        Optional<User> studentOpt = userRepository.findByUsername("student");
        if (!studentOpt.isPresent()) {
            System.out.println("Student user not found, skipping transaction creation");
            return;
        }
        
        User student = studentOpt.get();
        List<Book> books = bookRepository.findAll();
        
        if (books.isEmpty()) {
            System.out.println("No books found, skipping transaction creation");
            return;
        }

        // Create some borrowed books (active loans)
        if (books.size() > 0) {
            Transaction borrowTransaction1 = new Transaction(student, books.get(0), Transaction.TransactionType.BORROW);
            borrowTransaction1.setTransactionDate(LocalDateTime.now().minusDays(5));
            borrowTransaction1.setDueDate(LocalDateTime.now().plusDays(9)); // Due in 9 days
            transactionRepository.save(borrowTransaction1);
            System.out.println("Created borrow transaction for: " + books.get(0).getTitle());
        }

        if (books.size() > 1) {
            Transaction borrowTransaction2 = new Transaction(student, books.get(1), Transaction.TransactionType.BORROW);
            borrowTransaction2.setTransactionDate(LocalDateTime.now().minusDays(10));
            borrowTransaction2.setDueDate(LocalDateTime.now().plusDays(4)); // Due in 4 days
            transactionRepository.save(borrowTransaction2);
            System.out.println("Created borrow transaction for: " + books.get(1).getTitle());
        }

        // Create an overdue book
        if (books.size() > 2) {
            Transaction overdueTransaction = new Transaction(student, books.get(2), Transaction.TransactionType.BORROW);
            overdueTransaction.setTransactionDate(LocalDateTime.now().minusDays(20));
            overdueTransaction.setDueDate(LocalDateTime.now().minusDays(6)); // Overdue by 6 days
            overdueTransaction.setStatus(Transaction.TransactionStatus.OVERDUE);
            overdueTransaction.setFineAmount(6.0); // $1 per day fine
            transactionRepository.save(overdueTransaction);
            System.out.println("Created overdue transaction for: " + books.get(2).getTitle());
        }

        // Create a reserved book
        if (books.size() > 3) {
            Transaction reserveTransaction = new Transaction(student, books.get(3), Transaction.TransactionType.RESERVE);
            reserveTransaction.setTransactionDate(LocalDateTime.now().minusDays(2));
            transactionRepository.save(reserveTransaction);
            System.out.println("Created reserve transaction for: " + books.get(3).getTitle());
        }

        // Create some returned books for history
        if (books.size() > 4) {
            Transaction returnTransaction1 = new Transaction(student, books.get(4), Transaction.TransactionType.BORROW);
            returnTransaction1.setTransactionDate(LocalDateTime.now().minusDays(30));
            returnTransaction1.setDueDate(LocalDateTime.now().minusDays(16));
            returnTransaction1.setReturnDate(LocalDateTime.now().minusDays(18));
            returnTransaction1.setStatus(Transaction.TransactionStatus.COMPLETED);
            transactionRepository.save(returnTransaction1);
            System.out.println("Created returned transaction for: " + books.get(4).getTitle());

            // Create return transaction
            Transaction returnTransaction2 = new Transaction(student, books.get(4), Transaction.TransactionType.RETURN);
            returnTransaction2.setTransactionDate(LocalDateTime.now().minusDays(18));
            returnTransaction2.setStatus(Transaction.TransactionStatus.COMPLETED);
            transactionRepository.save(returnTransaction2);
        }

        if (books.size() > 5) {
            Transaction returnTransaction3 = new Transaction(student, books.get(5), Transaction.TransactionType.BORROW);
            returnTransaction3.setTransactionDate(LocalDateTime.now().minusDays(25));
            returnTransaction3.setDueDate(LocalDateTime.now().minusDays(11));
            returnTransaction3.setReturnDate(LocalDateTime.now().minusDays(15));
            returnTransaction3.setStatus(Transaction.TransactionStatus.COMPLETED);
            transactionRepository.save(returnTransaction3);
            System.out.println("Created returned transaction for: " + books.get(5).getTitle());

            // Create return transaction
            Transaction returnTransaction4 = new Transaction(student, books.get(5), Transaction.TransactionType.RETURN);
            returnTransaction4.setTransactionDate(LocalDateTime.now().minusDays(15));
            returnTransaction4.setStatus(Transaction.TransactionStatus.COMPLETED);
            transactionRepository.save(returnTransaction4);
        }

        System.out.println("Sample transactions created successfully!");
        System.out.println("Student should now see real-time statistics on dashboard");
    }

    /**
     * Create a new transaction
     */
    public Transaction createTransaction(User user, Book book, Transaction.TransactionType type) {
        Transaction transaction = new Transaction(user, book, type);
        Transaction saved = transactionRepository.save(transaction);
        // Gamification: award points for borrow action
        try { if (type == Transaction.TransactionType.BORROW) gamificationService.onBorrow(user, saved); } catch (Exception e) { System.err.println("Gamification error on borrow: " + e.getMessage()); }
        return saved;
    }

    /**
     * Get all transactions for a user
     */
    public List<Transaction> getUserTransactions(User user) {
        return transactionRepository.findByUser(user);
    }

    /**
     * Get active borrowed books for a user
     */
    public List<Transaction> getActiveBorrowedBooks(User user) {
        return transactionRepository.findByUserAndTypeAndReturnDateIsNull(user, Transaction.TransactionType.BORROW);
    }

    /**
     * Return a book
     */
    public Transaction returnBook(Transaction borrowTransaction) {
        borrowTransaction.setReturnDate(LocalDateTime.now());
        borrowTransaction.setStatus(Transaction.TransactionStatus.COMPLETED);
        
        // Create return transaction
        Transaction returnTransaction = new Transaction(
            borrowTransaction.getUser(), 
            borrowTransaction.getBook(), 
            Transaction.TransactionType.RETURN
        );
        returnTransaction.setStatus(Transaction.TransactionStatus.COMPLETED);
        
        transactionRepository.save(borrowTransaction);

        // Gamification: award points for return
        boolean onTime = !borrowTransaction.isOverdue();
        try { gamificationService.onReturn(borrowTransaction.getUser(), borrowTransaction, onTime); } catch (Exception e) { System.err.println("Gamification error on return: " + e.getMessage()); }

        return transactionRepository.save(returnTransaction);
    }
}