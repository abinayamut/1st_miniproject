# Smart Library Startup Script
Write-Host "=== Smart Library Management System ===" -ForegroundColor Green
Write-Host "Setting up environment..." -ForegroundColor Yellow

# Set working directory
Set-Location "C:\Users\HP\OneDrive\Documents\java programs\College works\mini project file\Smart_Library\library-management"

# Set JAVA_HOME
$env:JAVA_HOME = "C:\Program Files\Eclipse Adoptium\jdk-21.0.8.9-hotspot"
$env:PATH = "$env:JAVA_HOME\bin;$env:PATH"

Write-Host "Java Version:" -ForegroundColor Cyan
& java -version

Write-Host "`nStarting application with H2 database..." -ForegroundColor Yellow
Write-Host "Application will be available at: http://localhost:8080" -ForegroundColor Green
Write-Host "Default login credentials:" -ForegroundColor Green
Write-Host "  Admin: admin / admin123" -ForegroundColor White
Write-Host "  Librarian: librarian / librarian123" -ForegroundColor White
Write-Host "  Student: student / student123" -ForegroundColor White
Write-Host "`nPress Ctrl+C to stop the application`n" -ForegroundColor Red

# Run with H2 profile
& ".\mvnw.cmd" spring-boot:run -Dspring-boot.run.profiles=h2