package com.example.library_management.service;

import com.example.library_management.entity.Transaction;
import com.example.library_management.entity.User;
import com.example.library_management.entity.UserPoints;
import com.example.library_management.repository.UserPointsRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;

@Service
public class GamificationService {

    @Autowired
    private UserPointsRepository userPointsRepository;

    @Transactional
    public void addPointsForEvent(User user, String event, Long points) {
        if (user == null) return;
        UserPoints up = userPointsRepository.findByUser(user).orElseGet(() -> new UserPoints(user));
        up.setPointsTotal(up.getPointsTotal() + (points == null ? 0L : points));
        up.setUpdatedAt(LocalDateTime.now());
        userPointsRepository.save(up);
    }

    // convenience methods
    public void onBorrow(User user, Transaction t) { addPointsForEvent(user, "BORROW", 1L); }
    public void onReturn(User user, Transaction t, boolean onTime) { addPointsForEvent(user, onTime ? "RETURN_ON_TIME" : "RETURN_LATE", onTime ? 5L : 0L); }
}
