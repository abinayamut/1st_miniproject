package com.example.library_management.service;

import com.example.library_management.entity.Book;
import com.example.library_management.repository.BookRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.PageImpl;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;

import jakarta.persistence.criteria.Predicate;
import java.util.ArrayList;
import java.util.List;

/**
 * Service for advanced book search functionality
 */
@Service
public class AdvancedSearchService {

    @Autowired
    private BookRepository bookRepository;

    /**
     * Search books with multiple filters
     */
    public Page<Book> searchBooks(SearchCriteria criteria, Pageable pageable) {
        Specification<Book> spec = createSpecification(criteria);
        return bookRepository.findAll(spec, pageable);
    }

    /**
     * Search books and return as list
     */
    public List<Book> searchBooks(SearchCriteria criteria) {
        Specification<Book> spec = createSpecification(criteria);
        return bookRepository.findAll(spec);
    }

    /**
     * Create JPA Specification based on search criteria
     */
    private Specification<Book> createSpecification(SearchCriteria criteria) {
        return (root, query, criteriaBuilder) -> {
            List<Predicate> predicates = new ArrayList<>();

            // Title search
            if (criteria.getTitle() != null && !criteria.getTitle().trim().isEmpty()) {
                predicates.add(criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("title")),
                    "%" + criteria.getTitle().toLowerCase() + "%"
                ));
            }

            // Author search
            if (criteria.getAuthor() != null && !criteria.getAuthor().trim().isEmpty()) {
                predicates.add(criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("author")),
                    "%" + criteria.getAuthor().toLowerCase() + "%"
                ));
            }

            // ISBN search
            if (criteria.getIsbn() != null && !criteria.getIsbn().trim().isEmpty()) {
                predicates.add(criteriaBuilder.like(
                    root.get("isbn"),
                    "%" + criteria.getIsbn() + "%"
                ));
            }

            // Genre filter
            if (criteria.getGenre() != null && !criteria.getGenre().trim().isEmpty()) {
                predicates.add(criteriaBuilder.equal(
                    criteriaBuilder.lower(root.get("genre")),
                    criteria.getGenre().toLowerCase()
                ));
            }

            // Publisher search
            if (criteria.getPublisher() != null && !criteria.getPublisher().trim().isEmpty()) {
                predicates.add(criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("publisher")),
                    "%" + criteria.getPublisher().toLowerCase() + "%"
                ));
            }

            // Publication year range
            if (criteria.getPublicationYearFrom() != null) {
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(
                    root.get("publicationYear"),
                    criteria.getPublicationYearFrom()
                ));
            }

            if (criteria.getPublicationYearTo() != null) {
                predicates.add(criteriaBuilder.lessThanOrEqualTo(
                    root.get("publicationYear"),
                    criteria.getPublicationYearTo()
                ));
            }

            // Pages range
            if (criteria.getPagesFrom() != null) {
                predicates.add(criteriaBuilder.greaterThanOrEqualTo(
                    root.get("pages"),
                    criteria.getPagesFrom()
                ));
            }

            if (criteria.getPagesTo() != null) {
                predicates.add(criteriaBuilder.lessThanOrEqualTo(
                    root.get("pages"),
                    criteria.getPagesTo()
                ));
            }

            // Availability filter
            if (criteria.getAvailableOnly() != null && criteria.getAvailableOnly()) {
                predicates.add(criteriaBuilder.greaterThan(
                    root.get("availableCopies"),
                    0
                ));
            }

            // Global keyword search (searches across multiple fields)
            if (criteria.getKeyword() != null && !criteria.getKeyword().trim().isEmpty()) {
                String keyword = "%" + criteria.getKeyword().toLowerCase() + "%";
                Predicate titleMatch = criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("title")), keyword);
                Predicate authorMatch = criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("author")), keyword);
                Predicate genreMatch = criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("genre")), keyword);
                Predicate descriptionMatch = criteriaBuilder.like(
                    criteriaBuilder.lower(root.get("description")), keyword);

                predicates.add(criteriaBuilder.or(titleMatch, authorMatch, genreMatch, descriptionMatch));
            }

            return criteriaBuilder.and(predicates.toArray(new Predicate[0]));
        };
    }

    /**
     * Get book suggestions based on partial input
     */
    public List<String> getBookSuggestions(String input, String field, int limit) {
        if (input == null || input.trim().isEmpty()) {
            return new ArrayList<>();
        }

        List<Book> books;
        String lowerInput = input.toLowerCase();

        switch (field.toLowerCase()) {
            case "title":
                books = bookRepository.findByTitleContainingIgnoreCase(lowerInput);
                return books.stream()
                    .map(Book::getTitle)
                    .distinct()
                    .limit(limit)
                    .toList();

            case "author":
                books = bookRepository.findByAuthorContainingIgnoreCase(lowerInput);
                return books.stream()
                    .map(Book::getAuthor)
                    .distinct()
                    .limit(limit)
                    .toList();

            case "genre":
                books = bookRepository.findByGenreIgnoreCase(lowerInput);
                return books.stream()
                    .map(Book::getGenre)
                    .distinct()
                    .limit(limit)
                    .toList();

            default:
                return new ArrayList<>();
        }
    }

    /**
     * Get all available genres
     */
    public List<String> getAllGenres() {
        return bookRepository.findAllGenres();
    }

    /**
     * Search criteria class
     */
    public static class SearchCriteria {
        private String title;
        private String author;
        private String isbn;
        private String genre;
        private String publisher;
        private Integer publicationYearFrom;
        private Integer publicationYearTo;
        private Integer pagesFrom;
        private Integer pagesTo;
        private Boolean availableOnly;
        private String keyword; // Global search across multiple fields

        // Default constructor
        public SearchCriteria() {}

        // Getters and setters
        public String getTitle() {
            return title;
        }

        public void setTitle(String title) {
            this.title = title;
        }

        public String getAuthor() {
            return author;
        }

        public void setAuthor(String author) {
            this.author = author;
        }

        public String getIsbn() {
            return isbn;
        }

        public void setIsbn(String isbn) {
            this.isbn = isbn;
        }

        public String getGenre() {
            return genre;
        }

        public void setGenre(String genre) {
            this.genre = genre;
        }

        public String getPublisher() {
            return publisher;
        }

        public void setPublisher(String publisher) {
            this.publisher = publisher;
        }

        public Integer getPublicationYearFrom() {
            return publicationYearFrom;
        }

        public void setPublicationYearFrom(Integer publicationYearFrom) {
            this.publicationYearFrom = publicationYearFrom;
        }

        public Integer getPublicationYearTo() {
            return publicationYearTo;
        }

        public void setPublicationYearTo(Integer publicationYearTo) {
            this.publicationYearTo = publicationYearTo;
        }

        public Integer getPagesFrom() {
            return pagesFrom;
        }

        public void setPagesFrom(Integer pagesFrom) {
            this.pagesFrom = pagesFrom;
        }

        public Integer getPagesTo() {
            return pagesTo;
        }

        public void setPagesTo(Integer pagesTo) {
            this.pagesTo = pagesTo;
        }

        public Boolean getAvailableOnly() {
            return availableOnly;
        }

        public void setAvailableOnly(Boolean availableOnly) {
            this.availableOnly = availableOnly;
        }

        public String getKeyword() {
            return keyword;
        }

        public void setKeyword(String keyword) {
            this.keyword = keyword;
        }
    }
}