package com.example.library_management.service;

import com.example.library_management.entity.User;
import com.example.library_management.entity.Role;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Service;

/**
 * Service for authentication-related utilities
 */
@Service
public class AuthenticationService {

    @Autowired
    private UserService userService;

    /**
     * Get the currently logged-in user
     */
    public User getCurrentUser() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        
        if (authentication == null || !authentication.isAuthenticated() || 
            authentication.getName().equals("anonymousUser")) {
            return null;
        }

        String username = authentication.getName();
        return userService.findByUsername(username).orElse(null);
    }

    /**
     * Get current user's role
     */
    public Role getCurrentUserRole() {
        User currentUser = getCurrentUser();
        return currentUser != null ? currentUser.getRole() : null;
    }

    /**
     * Check if current user has specific role
     */
    public boolean hasRole(Role role) {
        Role currentRole = getCurrentUserRole();
        return currentRole != null && currentRole.equals(role);
    }

    /**
     * Check if current user is admin
     */
    public boolean isAdmin() {
        return hasRole(Role.ADMIN);
    }

    /**
     * Check if current user is librarian
     */
    public boolean isLibrarian() {
        return hasRole(Role.LIBRARIAN);
    }

    /**
     * Check if current user is student
     */
    public boolean isStudent() {
        return hasRole(Role.STUDENT);
    }

    /**
     * Get dashboard URL for current user
     */
    public String getDashboardUrl() {
        Role role = getCurrentUserRole();
        if (role == null) {
            return "/login";
        }

        switch (role) {
            case ADMIN:
                return "/admin/dashboard";
            case LIBRARIAN:
                return "/librarian/dashboard";
            case STUDENT:
                return "/student/dashboard";
            default:
                return "/";
        }
    }

    /**
     * Check if user is authenticated
     */
    public boolean isAuthenticated() {
        Authentication authentication = SecurityContextHolder.getContext().getAuthentication();
        return authentication != null && authentication.isAuthenticated() && 
               !authentication.getName().equals("anonymousUser");
    }
}