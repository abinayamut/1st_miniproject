# Setup & Local Development

This guide helps you run Smart Library locally on Windows and troubleshoot common issues.

## Prerequisites
- Java 21 (Adoptium / Temurin recommended)
- Maven (optional - project includes `mvnw` wrapper)
- MySQL (optional) or use H2 dev profile

## Environment
Project root for the Spring Boot app: `library-management`

### Using the Maven wrapper (recommended)
Open Command Prompt (not PowerShell) to avoid path parsing issues caused by spaces in Windows paths.

```powershell
cd "<repo-root>\library-management"
# Build
mvnw.cmd clean package
# Run
mvnw.cmd spring-boot:run
```

### PowerShell gotcha
If you see an error like `Files\Eclipse was unexpected at this time` when running `mvnw.cmd` from PowerShell, use Command Prompt instead or run the bundled batch files:
- `run-project.bat`
- `start-library.bat`

Alternatively, run the PowerShell helper in the repo: `run-app.ps1`.

### Using H2 for development
If you don't have MySQL locally, use the H2 profile with the included `application-h2.properties`.
Edit `src/main/resources/application.properties` or launch with the `--spring.profiles.active=h2` flag.

### Database
Default MySQL connection (see `application.properties`):
```
jdbc:mysql://localhost:3306/studentdb_1
```
If you use MySQL, create the database and configure `spring.datasource.username` and `spring.datasource.password` in `application.properties`.

## Seeded Data
`DataInitializer` seeds default users (admin/librarian/student) and sample books. I also added sample transactions to help the dashboard show real data.

## Common Commands
- Build: `mvnw.cmd clean package`
- Run: `mvnw.cmd spring-boot:run`
- Tests: `mvnw.cmd test`
- Clean: `mvnw.cmd clean`

## Troubleshooting
- If the app fails to start due to DB connection: switch to H2 (`--spring.profiles.active=h2`) or fix MySQL credentials.
- If static templates don't refresh: ensure you are running in dev mode with `spring.thymeleaf.cache=false` in `application.properties` for development.

## Windows Tips
- Use Command Prompt when invoking `mvnw.cmd` to avoid PowerShell path quirks.
- If you must use PowerShell, wrap paths in double quotes and avoid concatenating commands with `&&` in older PowerShell versions.

