package com.example.library_management.service;

import com.example.library_management.entity.User;
import com.example.library_management.entity.Role;
import com.example.library_management.repository.UserRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Optional;

@Service
@Transactional
public class UserService {
    
    @Autowired
    private UserRepository userRepository;
    
    @Autowired
    private PasswordEncoder passwordEncoder;
    
    // Create new user
    public User createUser(User user) {
        // Check if username or email already exists
        if (userRepository.existsByUsername(user.getUsername())) {
            throw new RuntimeException("Username already exists: " + user.getUsername());
        }
        
        if (userRepository.existsByEmail(user.getEmail())) {
            throw new RuntimeException("Email already exists: " + user.getEmail());
        }
        
        // Encode password before saving
        user.setPassword(passwordEncoder.encode(user.getPassword()));
        return userRepository.save(user);
    }
    
    // Create default users if they don't exist
    public void createDefaultUsers() {
        // Create default admin
        if (!userRepository.existsByUsername("admin")) {
            User admin = new User("admin", "admin123", "admin@smartlibrary.com", 
                               "System Administrator", Role.ADMIN);
            createUser(admin);
        }
        
        // Create default librarian
        if (!userRepository.existsByUsername("librarian")) {
            User librarian = new User("librarian", "librarian123", "librarian@smartlibrary.com", 
                                    "Head Librarian", Role.LIBRARIAN);
            createUser(librarian);
        }
        
        // Create default student
        if (!userRepository.existsByUsername("student")) {
            User student = new User("student", "student123", "student@smartlibrary.com", 
                                  "Student User", Role.STUDENT);
            createUser(student);
        }
    }
    
    // Find user by username
    public Optional<User> findByUsername(String username) {
        return userRepository.findByUsername(username);
    }
    
    // Find user by email
    public Optional<User> findByEmail(String email) {
        return userRepository.findByEmail(email);
    }
    
    // Find user by ID
    public Optional<User> findById(Long id) {
        return userRepository.findById(id);
    }
    
    // Get all users
    public List<User> getAllUsers() {
        return userRepository.findAll();
    }
    
    // Get users by role
    public List<User> getUsersByRole(Role role) {
        return userRepository.findByRole(role);
    }
    
    // Get active users
    public List<User> getActiveUsers() {
        return userRepository.findByIsActive(true);
    }
    
    // Update user
    public User updateUser(User user) {
        return userRepository.save(user);
    }
    
    // Toggle user status
    public User toggleUserStatus(Long userId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setActive(!user.isActive());
            return userRepository.save(user);
        }
        throw new RuntimeException("User not found with id: " + userId);
    }
    
    // Update user password
    public void updatePassword(Long userId, String newPassword) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setPassword(passwordEncoder.encode(newPassword));
            userRepository.save(user);
        }
    }
    
    // Deactivate user
    public void deactivateUser(Long userId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setActive(false);
            userRepository.save(user);
        }
    }
    
    // Activate user
    public void activateUser(Long userId) {
        Optional<User> userOpt = userRepository.findById(userId);
        if (userOpt.isPresent()) {
            User user = userOpt.get();
            user.setActive(true);
            userRepository.save(user);
        }
    }
    
    // Delete user
    public void deleteUser(Long userId) {
        userRepository.deleteById(userId);
    }
    
    // Check if user exists by username
    public boolean existsByUsername(String username) {
        return userRepository.existsByUsername(username);
    }
    
    // Check if user exists by email
    public boolean existsByEmail(String email) {
        return userRepository.existsByEmail(email);
    }
    
    // Get user statistics
    public UserStats getUserStats() {
        long totalUsers = userRepository.count();
        long admins = userRepository.findByRole(Role.ADMIN).size();
        long librarians = userRepository.findByRole(Role.LIBRARIAN).size();
        long students = userRepository.findByRole(Role.STUDENT).size();
        long activeUsers = userRepository.findByIsActive(true).size();
        
        return new UserStats(totalUsers, admins, librarians, students, activeUsers);
    }
    
    // Inner class for user statistics
    public static class UserStats {
        private final long totalUsers;
        private final long admins;
        private final long librarians;
        private final long students;
        private final long activeUsers;
        
        public UserStats(long totalUsers, long admins, long librarians, long students, long activeUsers) {
            this.totalUsers = totalUsers;
            this.admins = admins;
            this.librarians = librarians;
            this.students = students;
            this.activeUsers = activeUsers;
        }
        
        // Getters
        public long getTotalUsers() { return totalUsers; }
        public long getAdmins() { return admins; }
        public long getLibrarians() { return librarians; }
        public long getStudents() { return students; }
        public long getActiveUsers() { return activeUsers; }
    }
}