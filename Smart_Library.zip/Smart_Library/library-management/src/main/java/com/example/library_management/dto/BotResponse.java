package com.example.library_management.dto;

public class BotResponse {
    private String reply;

    public BotResponse() {}

    public BotResponse(String reply) { this.reply = reply; }

    public String getReply() { return reply; }
    public void setReply(String reply) { this.reply = reply; }
}
